#!/usr/bin/env python

import cv2
import numpy as np


def convert_any_img_to_nv12(img_data):
    img_shape = img_data.shape
    # convert image format to YUV_I420
    nv12_data = cv2.cvtColor(img_data, cv2.COLOR_BGR2YUV_I420)
    uv_start_idx = img_shape[0] * img_shape[1]
    u_or_v_size = ((img_shape[0] + 1) // 2) * ((img_shape[1] + 1) // 2)
    nv12_y_data = nv12_data.flatten()[0:uv_start_idx]
    nv12_u_data = nv12_data.flatten()[uv_start_idx:uv_start_idx + u_or_v_size]
    nv12_v_data = nv12_data.flatten()[uv_start_idx + u_or_v_size:uv_start_idx +
                                      2 * u_or_v_size]
    # truncate YUV data as int8
    nv12_y_data = nv12_y_data.astype(np.uint8)
    nv12_u_data = nv12_u_data.astype(np.uint8)
    nv12_v_data = nv12_v_data.astype(np.uint8)
    # reformat data as nv12
    nv12_res = nv12_y_data
    nv12_res = np.resize(nv12_res, [
        uv_start_idx + u_or_v_size * 2,
    ])
    for i in range(u_or_v_size):
        nv12_res[uv_start_idx + 2 * i] = nv12_u_data[i]
        nv12_res[uv_start_idx + 2 * i + 1] = nv12_v_data[i]
    return nv12_res, img_shape


def convert_nv12_to_yuv444_int8(img_data, img_shape):
    nv12_data = img_data
    uv_start_idx = img_shape[0] * img_shape[1]
    nv12_y_data = nv12_data.flatten()[0:uv_start_idx]
    u_id = np.arange(len(nv12_data))
    u_id = np.bitwise_and(u_id >= uv_start_idx, u_id % 2 == uv_start_idx % 2)
    nv12_u_data = nv12_data.flatten()[u_id]
    v_id = np.arange(len(nv12_data))
    v_id = np.bitwise_and(v_id >= uv_start_idx, v_id % 2 != uv_start_idx % 2)
    nv12_v_data = nv12_data.flatten()[v_id]
    # truncate YUV data as int8
    nv12_y_data = nv12_y_data.astype(np.uint8)
    nv12_u_data = nv12_u_data.astype(np.uint8)
    nv12_v_data = nv12_v_data.astype(np.uint8)
    # reformat data as nv12
    yuv444_res = np.zeros(img_shape, dtype=np.int8)
    # yuv444_res = np.zeros(img_shape, dtype=np.uint8)
    for h in range(img_shape[0]):
        # centralize yuv 444 data for inference framework
        for w in range(img_shape[1]):
            yuv444_res[h][w][0] = (
                nv12_y_data[h * img_shape[1] + w] - 128).astype(np.int8)
            yuv444_res[h][w][1] = (nv12_u_data[int(h / 2) * int(
                (img_shape[1] + 1) / 2) + int(w / 2)] - 128).astype(np.int8)
            yuv444_res[h][w][2] = (nv12_v_data[int(h / 2) * int(
                (img_shape[1] + 1) / 2) + int(w / 2)] - 128).astype(np.int8)
            # yuv444_res[h][w][0] = nv12_y_data[h * img_shape[1] + w]
            # yuv444_res[h][w][1] = nv12_u_data[int(h / 2) * int(img_shape[1] / 2) + int(w / 2)]
            # yuv444_res[h][w][2] = nv12_v_data[int(h / 2) * int(img_shape[1] / 2) + int(w / 2)]
    return yuv444_res
