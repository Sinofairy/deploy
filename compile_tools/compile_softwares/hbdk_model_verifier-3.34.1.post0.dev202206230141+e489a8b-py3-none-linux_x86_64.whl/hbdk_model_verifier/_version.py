__full_version__ = """\
version: 3.34.1.post0.dev202206230141+e489a8b
runtime version: 3.14.8.post0.dev202206230141+e489a8b
cmake_build_type: relo3withdebinfowithassert
supported_march: bernoulli, bernoulli2, bayes, 
git_version: e489a8b
git_full_commit_hash: e489a8bbacdbb61ce0406053fa127b5d9b1717dd
release_type: public


"""
