__full_version__ = """\
version: 3.28.2
runtime version: 3.13.28
cmake_build_type: relo3withdebinfowithassert
supported_march: bernoulli, bernoulli2, bayes, 
git_version: 1d0b0e6
git_full_commit_hash: 1d0b0e67cf3faca731a11b7380c4073f6026e2bd
release_type: public


"""
