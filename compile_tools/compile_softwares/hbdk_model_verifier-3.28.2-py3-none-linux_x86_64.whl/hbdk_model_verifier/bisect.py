r"""
Module for bisect
"""

from enum import Enum
from typing import Dict, Optional
from collections import OrderedDict
import unittest


class BisectStatus(Enum):
    Success = 0
    Fail = 1
    Skip = 2


class Bisect:
    def __init__(self, start: int, min_val: int, max_val: int,
                 initial_step: int, fail_on_low: bool):
        r"""
        :param fail_on_low: When true, assume exists a value A, and
                            it fails when (min <= x <=A ), for all values of x (not considering skip)
                            and it succeeds  when (min <=
        """
        assert min_val <= start <= max_val, "Invalid start=%d, or min=%d, or max=%d" % (
            start, min_val, max_val)

        self.start = start
        self.min = min_val
        self.max = max_val
        self.initial_step = initial_step
        self.cur = None
        self.cur_step_index = 0
        self.history = OrderedDict()  # type: Dict[int, BisectStatus]
        self.fail_on_low = fail_on_low

    def add_result(self, value: int, status: BisectStatus):
        self.history[value] = status

    def tested(self, value):
        return value in self.history

    def skipped(self, value):
        return self.history.get(value) == BisectStatus.Skip

    def get_untested_nearby_value(self, value: int):
        for i in range(self.max - self.min + 1):
            val = value + i
            val = max(self.min, val)
            val = min(self.max, val)
            if not self.tested(val):
                return val
            val = value - i
            val = max(self.min, val)
            val = min(self.max, val)
            if not self.tested(val):
                return val

    def next_value(self) -> Optional[int]:
        success_val = self.get_most_important_success_value()
        failed_val = self.get_most_important_failed_value()
        if success_val is None and failed_val is None:
            if self.skipped(self.start):
                self.cur = self.get_untested_nearby_value(self.start)
            elif not self.tested(self.start):
                self.cur = self.start
            else:
                self.cur = None
        elif (success_val is None) or (failed_val is None):
            abs_step = (self.initial_step >= 0) and self.initial_step or (
                -self.initial_step)
            if failed_val is None:
                assert success_val is not None
                if self.fail_on_low:
                    self.cur = self.get_untested_nearby_value(success_val -
                                                              abs_step)
                else:
                    self.cur = self.get_untested_nearby_value(success_val +
                                                              abs_step)
            else:
                if self.fail_on_low:
                    self.cur = self.get_untested_nearby_value(failed_val +
                                                              abs_step)
                else:
                    self.cur = self.get_untested_nearby_value(failed_val -
                                                              abs_step)
        else:
            cur = self.get_untested_nearby_value(
                (success_val + failed_val) // 2)
            if (success_val < cur < failed_val) or (failed_val < cur <
                                                    success_val):
                self.cur = cur
            else:
                self.cur = None
        return self.cur

    def get_most_important_success_value(self) -> Optional[int]:
        success_values = [
            value for value in self.history.keys()
            if self.history[value] == BisectStatus.Success
        ]
        if self.fail_on_low:
            return min(success_values, default=None)
        return max(success_values, default=None)

    def get_most_important_failed_value(self) -> Optional[int]:
        failed_values = [
            value for value in self.history.keys()
            if self.history[value] == BisectStatus.Fail
        ]
        if self.fail_on_low:
            return max(failed_values, default=None)
        return min(failed_values, default=None)


class TestBisect(unittest.TestCase):
    def test_noskip(self):
        b = Bisect(
            start=800,
            min_val=600,
            max_val=850,
            initial_step=-50,
            fail_on_low=True)
        Success = BisectStatus.Success
        Fail = BisectStatus.Fail
        nexts = [800, 750, 775, 762, 768, 771, 773, 772]
        statuses = [Success, Fail, Success, Fail, Fail, Fail, Success, Fail]
        for i, next in enumerate(nexts):
            status = statuses[i]
            v = b.next_value()
            self.assertEqual(v, next)
            b.add_result(v, status)
        self.assertIs(b.next_value(), None)
        self.assertEqual(b.get_most_important_failed_value(), 772)
        self.assertEqual(b.get_most_important_success_value(), 773)

    def test_skip(self):
        b = Bisect(
            start=800,
            min_val=600,
            max_val=850,
            initial_step=-30,
            fail_on_low=True)
        Success = BisectStatus.Success
        Fail = BisectStatus.Fail
        Skip = BisectStatus.Skip
        nexts = [
            800, 770, 785, 786, 784, 787, 783, 788, 782, 789, 781, 790, 780
        ]
        statuses = [
            Success, Fail, Skip, Skip, Skip, Skip, Skip, Skip, Skip, Skip,
            Skip, Success, Fail
        ]
        for i, next in enumerate(nexts):
            status = statuses[i]
            v = b.next_value()
            self.assertEqual(v, next)
            b.add_result(v, status)
        self.assertIs(b.next_value(), None)
        self.assertEqual(b.get_most_important_failed_value(), 780)
        self.assertEqual(b.get_most_important_success_value(), 790)
