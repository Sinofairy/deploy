#!/usr/bin/env python

import os
import re
import argparse
import warnings

try:
    import readline
except ImportError:
    warnings.warn(
        "Fail to import module readline. Tab completion will not be available")
    readline = None


class bcolors:
    HEADER = '\033[95m'
    OKBLUE = '\033[94m'
    OKGREEN = '\033[92m'
    WARNING = '\033[93m'
    FAIL = '\033[91m'
    ENDC = '\033[0m'
    BOLD = '\033[1m'
    UNDERLINE = '\033[4m'


RE_SPACE = re.compile('.*\s+$', re.M)


class Completer(object):
    def __init__(self, choices):
        self.choices = choices

    def _listdir(self, root):
        "List directory 'root' appending the path separator to subdirs."
        res = []
        for name in os.listdir(root):
            path = os.path.join(root, name)
            if os.path.isdir(path):
                name += os.sep
            res.append(name)
        return res

    def _complete_path(self, path=None):
        "Perform completion of filesystem path."
        if not path:
            return self._listdir('.')
        dirname, rest = os.path.split(path)
        tmp = dirname if dirname else '.'
        res = [
            os.path.join(dirname, p)
            for p in self._listdir(tmp)
            if p.startswith(rest)
        ]
        # more than one match, or single match which does not exist (typo)
        if len(res) > 1 or not os.path.exists(path):
            return res
        # resolved to a single directory, so return list of files below it
        if os.path.isdir(path):
            return [os.path.join(path, p) for p in self._listdir(path)]
        # exact file match terminates this completion
        return [path + ' ']

    def complete(self, text, state):
        "Generic readline completion entry point."
        if self.choices:
            comp = [str(x) for x in self.choices]
        else:
            comp = self._complete_path(text)
        return comp[state] if state < len(comp) else None


class InteractiveArgParseResult():
    def __init__(self, parser, print_ok=False):
        """
        Use
        args = InteractiveArgParseResult(parser)
        instead of
        args = parser.parse_args
        """
        self.parser = parser
        self.print_ok = print_ok
        self.ever_ask_for_anything = False
        self.namespace = parser.parse_args()
        setattr(self.namespace, 'iapr_disable_check_duplication', True)

    def ever_ask(self):
        return self.ever_ask_for_anything

    def parse_args(self, args):
        self.parser.parse_args(args=args, namespace=self.namespace)

    def restore_string(self):
        """
        restore result back to original string, not including executable itself
        :return:
        """

        s = []
        for k, d in self.parser._option_string_actions.items():
            if not hasattr(self.namespace, d.dest):
                continue  # no string for this option

            value = getattr(self.namespace, d.dest)
            if not value or value == d.default:
                continue  # no string for this option

            if isinstance(d, argparse._AppendAction):
                values = value
            elif isinstance(d, argparse._StoreTrueAction):
                values = ''
            else:
                values = [value]

            if isinstance(d, argparse._StoreTrueAction):
                s += [k]
            else:
                for v in values:
                    s += [k, str(v)]

        return ' '.join(s)

    def get(self, name):
        """
        Get parser result, may be None.
        Do not ask user for input.
        """
        return getattr(self.namespace, name)

    def get_argument_info(self, name):
        # from name, get the information when argparse.add_argument()
        for k, d in self.parser._option_string_actions.items():
            if d.dest == name:
                return k, d
        else:
            assert False, 'invalid name %s' % name

    def ask(self,
            name,
            problem=None,
            choices=None,
            append=False,
            print_key_and_help=True):
        """
        Ask user for input (if choices is None) or select from choices.
        """
        argument_key, argument_info = self.get_argument_info(name)
        is_appending = append and isinstance(argument_info,
                                             argparse._AppendAction)

        # print help information
        if print_key_and_help:
            prompt = '\n' + argument_key
            if argument_info.help:
                prompt += ', %s\n' % argument_info.help
            if problem:
                prompt += 'error: %s\n' % problem
        else:
            prompt = '\nerror: %s' % problem
        argument_value = None

        if readline:
            readline.set_completer_delims(' \t\n;')
            readline.parse_and_bind("tab: complete")
            if choices:
                comp = Completer(range(1, len(choices) + 1))
            else:
                comp = Completer([])
            readline.set_completer(comp.complete)
        # choices, select
        if choices:
            if len(choices) == 1:  # only 1 choice
                if self.get(name) != None and self.get(name) != choices[0]:
                    print(prompt)
                    print("[1] go on with the only proper argument choice ",
                          argument_key, " = ", choices[0])
                    print("[2] exit")
                    while argument_value is None:
                        try:
                            s = 'select from the above choices (1~2): '
                            i = int(input(s))
                            if i == 1:
                                argument_value = str(choices[0])
                                break
                            elif i == 2:
                                exit(1)
                            else:
                                pass
                        except ValueError:
                            pass
                        print('invalid input!')
                else:
                    print('[%sAUTO%s]' % (bcolors.OKGREEN, bcolors.ENDC),
                          argument_key, str(choices[0]))
                    argument_value = str(choices[0])
            else:  # user must choose
                self.ever_ask_for_anything = True
                print(prompt)
                for i, choice in enumerate(choices, 1):
                    print('[%d] %s' % (i, str(choice)))
                while argument_value is None:
                    try:
                        s = 'select from the above choices (1~%d): ' % len(
                            choices)
                        i = int(input(s))
                        if 1 <= i <= len(choices):
                            argument_value = str(choices[i - 1])
                            break
                    except ValueError:
                        pass
                    print('invalid input!')
        else:  # user input string, accepts empty string
            self.ever_ask_for_anything = True
            while argument_value is None:
                obj = getattr(self.namespace, name)
                if is_appending and obj:
                    this_prompt = prompt + '\ncurrent="%s", append input or type "clear" or "delete": ' % str(
                        obj)
                    while argument_value is None:
                        argument_value = input(this_prompt).strip()

                    if argument_value == 'clear':
                        setattr(self.namespace, name, None)
                        return self.get(name)
                    elif argument_value == 'delete':
                        del obj[-1]
                        return self.get(name)
                else:
                    setattr(self.namespace, name, None)
                    this_prompt = prompt + '\nyour input: '
                    while argument_value is None:
                        argument_value = input(this_prompt).strip()

        if isinstance(argument_info, argparse._StoreTrueAction):
            if argument_value == 'True':
                self.namespace = self.parser.parse_args(
                    args=[argument_key], namespace=self.namespace)
        else:
            self.namespace = self.parser.parse_args(
                args=[argument_key, argument_value], namespace=self.namespace)
        return self.get(name)

    def get_or_ask(self, name, description=None, choices=None, append=False):
        r = self.get(name)
        if r is None:
            return self.ask(name, description, choices, append)

    def get_or_ask_until_ok(self,
                            name,
                            choices=None,
                            checker=None,
                            append=False,
                            ignore_default=False,
                            msg=None):
        """
        get or ask, until checker(self.get(name)) exits normally
        :param checker: a function, which raise error with string if invalid arg
        :return:
        """

        argument_key, argument_info = self.get_argument_info(name)

        is_first_time = True

        while True:
            r = self.get(name)
            if ignore_default and is_first_time:
                r = None

            reason = 'ok'
            if r is None and argument_info.default is not None:
                reason = 'missing ' + argument_key
            elif callable(checker):
                try:
                    checker(r)
                except Exception as e:
                    reason = str(e)

            if reason is 'ok':  # this arg is OK
                if self.print_ok and not is_first_time:
                    print('[%sOK%s]   %s %s' % (bcolors.OKGREEN, bcolors.ENDC,
                                                argument_key, r))
                    print('-' * 70 + '\n')
                return r
            else:
                if is_first_time:
                    print('[%sBAD%s]  %s\t%s' %
                          (bcolors.FAIL, bcolors.ENDC, argument_key,
                           argument_info.help))
                    is_first_time = False
                if msg:
                    reason += '. ' + msg
                self.ask(
                    name, reason, choices, append, print_key_and_help=False)


if __name__ == '__main__':
    """
    for testing
    """

    parser = argparse.ArgumentParser()
    parser.add_argument('--hbm', help='Specify the hbm')
    parser.add_argument('--model-name', help='Model name in the hbm')
    parser.add_argument(
        '--yuv-shape', action='append', help='input shapes for the model')

    iapr = InteractiveArgParseResult(parser)

    iapr.get_or_ask_until_ok('hbm')

    # suppose we have loaded valid model names in the hbm
    model_names_to_input_number = {
        'resnet18': 3,
        'resnet50': 2,
        'resnet101': 4
    }

    def check_model_name(model_name):
        assert model_name in model_names_to_input_number.keys(
        ), 'invalid model name, should be one of ' + str(
            model_names_to_input_number.keys())

    iapr.get_or_ask_until_ok(
        'model_name',
        choices=tuple(model_names_to_input_number.keys()),
        checker=check_model_name)

    # suppose we have known the model's input number
    input_number = model_names_to_input_number[iapr.get('model_name')]

    def check_yuv_shape(yuv_shapes):
        yuv_shape_int = []
        for yuv_shape in yuv_shapes:
            nhwc = str(yuv_shape).strip().lower().split('x')
            assert len(nhwc) == 2, 'shape should be HxW, but %s' % yuv_shape
            nhwc = [int(x) for x in nhwc]
            assert nhwc[0] % 2 == 0 and nhwc[
                1] % 2 == 0, 'shape should be even, but %s' % yuv_shape
            yuv_shape_int.append(nhwc)
        assert len(
            yuv_shape_int
        ) == input_number, 'must specify %d YUV shapes' % input_number
        return yuv_shape_int

    iapr.get_or_ask_until_ok('yuv_shape', checker=check_yuv_shape, append=True)

    print('\n\nUse the following command to repeat this run:')
    print(iapr.restore_string())
