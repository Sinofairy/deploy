# -*- coding: utf-8 -*-
"""Get various HBDK related path or compiler options."""

import os
import sys
import argparse
import collections
import hbdk


class Config:
    """Helper class to get path of HBDK

    Attributes:
    prefix: root path of HBDK installation
    bin_prefix: The directory where HBDK executable locates
    include_dir: The include directory of HBDK header files.
    include_flag: The compiler flag to include HBDK header.
    cmake_dir: The cmake directory under the HBDK prefix
    """
    prefix = os.path.realpath(os.path.dirname(hbdk.__file__))
    bin_prefix = os.path.join(prefix, "bin")
    cmake_dir = os.path.join(prefix, "cmake")


def main() -> None:
    """main() function for hbdk-config"""
    parser = argparse.ArgumentParser(
        description="print various HBDK related path or compiler flags")

    def add_arg(*args, **kwargs):
        parser.add_argument(
            *args, required=False, action="store_true", **kwargs)

    add_arg("--prefix", help="Print the root path of HBDK installation")
    add_arg(
        "--bin-prefix",
        help="Print the directory where HBDK executable locates")
    add_arg("--cmake-dir", help="Print the cmake directory under HBDK prefix")
    add_arg("--version", help="Print the version of HBDK")

    vargs = vars(parser.parse_args())
    vargs = collections.OrderedDict(vargs)

    if not [x for x in vargs.values() if x is True]:
        parser.print_usage()
        print(
            "Error: At least one argument should be specified",
            file=sys.stderr)
        sys.exit(1)
    else:
        conversions = {
            'prefix': Config.prefix,
            'bin_prefix': Config.bin_prefix,
            'cmake_dir': Config.cmake_dir,
            'version': hbdk.__version__,
        }

        for arg, value in vargs.items():
            if value:
                print(conversions[arg])
        sys.exit(0)


if __name__ == "__main__":
    main()
