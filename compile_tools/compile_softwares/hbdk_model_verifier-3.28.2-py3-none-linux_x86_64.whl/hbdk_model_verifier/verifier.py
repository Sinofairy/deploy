#!/usr/bin/env python

import logging

logging.basicConfig(
    format="%(asctime)s %(name)s:%(levelname)s:%(message)s",
    datefmt="%m-%d-%Y %H:%M:%S",
    level=logging.INFO)

import argparse
import datetime
import subprocess
import numpy as np
import sys
import os
import tempfile
import json
import re
import pprint
import traceback
import cv2
import socket
import time
import fcntl
import signal
import shutil
from typing import Optional, Dict, List, Tuple
from paramiko import ssh_exception

sys.path.append(os.path.dirname(__file__))
from image_util import *
from bpu_connect import *
from zlib import crc32
import hbdk
import hbdk_model_verifier
import hbdk_model_verifier._version
import iargparse
import threading
import signal
import errno
import math
import shlex
from contextlib import contextmanager
from hbdk.proto import onnx_pb2
from collections import OrderedDict

from hbdk.util.parser import add_warning_for_duplidate_arguments

#from .bisect import Bisect, BisectStatus

arg_dict = {}

supported_image_ext = ('y', 'yuv', 'jpg', 'png', 'jpeg')


def exit_gracefully_by_sig(sig, _):
    print("Receive signal {}. Exit".format(sig), file=sys.stderr, flush=True)
    while True:
        raise KeyboardInterrupt


def register_exit_gracefully_handler():
    signals = [
        signal.SIGTERM, signal.SIGQUIT, signal.SIGHUP, signal.SIGUSR1,
        signal.SIGUSR2
    ]
    for s in signals:
        signal.signal(s, exit_gracefully_by_sig)


class OnnxModel:
    """Onnx Model utility"""

    def __init__(self, model):
        self.model = model
        self.model_dict = self.to_dict()

    def has_tensor_by_name(self, name):
        return name in self.model_dict

    def get_tensor_by_name(self, name):
        return self.model_dict[name]

    @classmethod
    def from_filename(cls, filename):
        model = onnx_pb2.ModelProto()
        model.ParseFromString(open(filename, 'rb').read())
        onnx_model = cls(model)
        return onnx_model

    def to_dict(self):
        """Convert onnx model to dictionary of tensor name and NDArray"""
        a = {}
        for tensor in self.model.graph.initializer:
            assert tensor.HasField('raw_data'), \
                "Data stored in other field is not implemented yet"
            shape = tuple(tensor.dims[:])
            dtype = self.onnx_type_to_dtype(tensor.data_type)
            data = tensor.raw_data[:]
            ndarray = np.ndarray(shape, dtype, data)
            a[tensor.name.replace("/", "_")] = ndarray
        return a

    @staticmethod
    def onnx_type_to_dtype(onnx_type):
        """Convert ONNX Type to Numpy dtype"""
        d = {
            onnx_pb2.TensorProto.INT8: np.int8,
            onnx_pb2.TensorProto.INT16: np.int16,
            onnx_pb2.TensorProto.INT32: np.int32,
            onnx_pb2.TensorProto.INT64: np.int64,
            onnx_pb2.TensorProto.UINT8: np.uint8,
            onnx_pb2.TensorProto.UINT16: np.uint16,
            onnx_pb2.TensorProto.UINT32: np.uint32,
            onnx_pb2.TensorProto.UINT64: np.uint64,
            onnx_pb2.TensorProto.FLOAT: np.float32,
            onnx_pb2.TensorProto.DOUBLE: np.float64,
        }
        return d[onnx_type]


def execute_shell_cmd(cmd, silent=False):
    if not silent:
        logging.info('executing cmd: ' + cmd)
    p = subprocess.Popen(
        cmd, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    out, err = p.communicate()
    if err is not None:
        if err.decode():
            err = err.decode(errors='replace')
    if out is not None:
        out = out.decode(errors='replace')
    return out, err, p.returncode


def get_file_crc32(filename):
    with open(filename, 'rb') as f:
        return crc32(f.read())


def shape_arg_to_tuple(str):
    try:
        ret = tuple(int(x) for x in str.strip().lower().split('x'))
    except ValueError:
        raise RuntimeError("Invalid shape string %s" % str)
    return ret


def shape_arg_to_tuple_list(str, delimiter=','):
    x = str.split(delimiter)
    ret = []
    for arg in x:
        if arg != '':
            ret.append(shape_arg_to_tuple(arg))
    return ret


def parse_hbm_to_json(hbm_path):
    assert isinstance(hbm_path, str), 'invalid hbm path %s' % str(hbm_path)
    assert os.path.isfile(hbm_path), 'cannot open %s' % hbm_path

    cmd = 'hbdk-disas --json ' + hbm_path
    out, err, returncode = execute_shell_cmd(cmd, silent=True)
    if returncode != 0:
        logging.critical('Fail to execute {}'.format(cmd))
        sys.exit(1)
    return json.loads(out)


class InputInfo:
    def __init__(self,
                 *,
                 input_idx: int,
                 feature_name: str,
                 filename: str,
                 valid_dim: List[int],
                 input_source: str,
                 image_shape: Optional[List[int]] = None,
                 image_stride: Optional[int] = None,
                 pyramid_stride_in_hbm: Optional[int] = None,
                 image_roi_coord: Optional[List[int]] = None,
                 image_roi_size: Optional[List[int]] = None,
                 element_type_name: str,
                 vio_config: Optional[str] = None,
                 pyramid_ds_factor: Optional[int] = None,
                 definer: Optional[str] = None):
        self.input_idx = input_idx
        self.feature_name = feature_name
        self.filename = filename
        self.valid_dim = valid_dim
        self.input_source = input_source.lower()
        self.element_type_name = element_type_name

        self.image_roi_coord = image_roi_coord
        self.image_roi_size = image_roi_size
        if image_shape:
            self.image_shape = list(image_shape)
            if not self.image_roi_coord:
                self.image_roi_coord = [0, 0]
            if not self.image_roi_size:
                self.image_roi_size = [
                    int(self.image_shape[0]),
                    int(self.image_shape[1])
                ]
        else:
            self.image_shape = None
        self.pyramid_stride_in_hbm = pyramid_stride_in_hbm
        self.vio_config = vio_config
        self.pyramid_ds_factor = pyramid_ds_factor
        if self.filename is not None:
            self.load_data_from_file()
        else:
            self.data = None
        self.image_stride = None
        self.stride_speicified_manually = False
        if self.input_source in ('pyramid', 'resizer'):
            if image_stride is None and self.filename is not None:
                self.image_stride = (self.image_shape[1] + 15) // 16 * 16
            elif image_stride is not None:
                self.image_stride = image_stride
                self.stride_speicified_manually = True
        self.pred_input_file = None
        self.bpu_input_file = None
        if self.input_source in ("pyramid",
                                 "resizer") and self.filename is not None:
            self.check_image_size()
        self.definer = definer

    def check_image_size(self):
        h = self.image_shape[0]
        w = self.image_shape[1]
        if self.image_shape[1] > self.image_stride:
            logging.critical(
                'The stride %d of the input image %s should be greater or equal to the image width %s'
                % (self.image_stride, self.filename, w))
            exit(1)
        image_prefix = "color"
        if self.is_one_channel():
            image_prefix = "gray"
        img_size = np.size(self.data)
        if not self.stride_speicified_manually:
            if self.is_one_channel():
                expect_size = h * w
            else:
                expect_size = h * w + ((h + 1) // 2) * ((w + 1) // 2) * 2
            if img_size != expect_size:
                logging.critical(
                    "%s image %s with shape %dx%d expect file size of %d bytes,"
                    " but %d bytes" % (image_prefix, self.filename, h, w,
                                       expect_size, img_size))
        else:
            if self.is_one_channel():
                expect_size = h * self.image_stride
            else:
                expect_size = h * self.image_stride + ((h + 1) // 2) * (
                    (self.image_stride + 1) // 2) * 2
            if img_size != expect_size:
                logging.critical(
                    "%s image %s with shape %dx%d and stride %d expect file size of %d bytes, but %d bytes"
                    % (image_prefix, self.filename, h, w, self.image_stride,
                       expect_size, img_size))
                exit(1)

    @property
    def ext(self):
        return self.filename.split('.')[-1]

    def is_one_channel(self):
        if self.image_shape is not None:
            return self.image_shape[-1] == 1
        else:
            return self.valid_dim[-1] == 1

    def is_y_or_nv12(self):
        return self.ext in ('y', 'yuv')

    def load_data_from_file(self):
        if self.ext == "txt":
            self.data = np.loadtxt(self.filename, dtype=np.int8)
        elif self.input_source == "ddr":
            self.data = np.frombuffer(
                open(self.filename, 'rb').read(), dtype=np.int8)
        elif self.is_y_or_nv12():
            self.data = np.frombuffer(
                open(self.filename, 'rb').read(), dtype=np.uint8)
            assert self.image_shape, "YUV must specify image shape"
        else:
            image = cv2.imread(self.filename)
            if self.image_shape is None:
                self.image_shape = list(image.shape)
            self.data = convert_any_img_to_nv12(image)[0]

    def generate_random_input_file(self):
        if self.filename is not None:
            logging.warning(
                'input file ' + self.filename +
                ' already exists! random input shall not be generated.')
            return
        filename = os.path.join(arg_dict['local_work_path'],
                                'random_input_' + str(self.input_idx))
        data = None
        if self.input_source == 'ddr':
            filename += '.bin'
            data_dtype = np.int8
            data_low = -128
            data_high = 127
            if self.element_type_name == 'int16':
                data_dtype = np.int16
                data_low = -32768
                data_high = 32767
            data = np.random.randint(
                low=data_low,
                high=data_high,
                size=self.valid_dim,
                dtype=data_dtype)
        elif self.input_source == 'pyramid':
            line_num = self.valid_dim[1]
            if self.is_one_channel():
                filename += '.y'
            else:
                filename += '.yuv'
                line_num += int((self.valid_dim[1] + 1) // 2)
            if self.image_shape is None:
                self.image_shape = self.valid_dim[1:]

            if self.image_stride is None:
                self.image_stride = self.image_shape[1]

            if self.image_stride != self.pyramid_stride_in_hbm and (
                    not self.vio_config):
                if self.image_stride == self.valid_dim[2]:
                    pass
                else:
                    if arg_dict['march'].find('bayes') != -1:
                        pass
                    else:
                        logging.critical(
                            'model input image file \'' + self.filename +
                            '\' width (' + str(self.image_stride) +
                            ') does not comply with pyramid input image stride specified when compiling model ('
                            + str(self.pyramid_stride_in_hbm) +
                            ') nor valid input width (' +
                            str(self.valid_dim[2]) +
                            '). Please provide another image with compatible width.'
                        )
                        raise RuntimeError
            data = np.random.randint(
                low=0,
                high=255,
                size=[line_num, self.image_stride],
                dtype=np.uint8)
        elif self.input_source == 'resizer':
            if self.is_one_channel():
                filename += '.y'
            else:
                filename += '.yuv'
            if self.image_shape is not None:
                line_num = self.image_shape[0] + 0 if self.is_one_channel(
                ) else int((self.image_shape[1] + 1) // 2)
                if self.image_stride is None:
                    self.image_stride = self.image_shape[1]
                data = np.random.randint(
                    low=0,
                    high=255,
                    size=[line_num, self.image_stride],
                    dtype=np.uint8)
            else:
                self.image_shape = [
                    540, 960, 1 if self.is_one_channel() else 3
                ]
                if self.image_stride is not None:
                    logging.warning(
                        "image stride will be override for random input " +
                        self.feature_name + " as random image width")
                    self.image_stride = 960
                line_num = self.image_shape[0] + 0 if self.is_one_channel(
                ) else int((self.image_shape[1] + 1) // 2)
                data = np.random.randint(
                    low=0,
                    high=255,
                    size=[line_num, self.image_stride],
                    dtype=np.uint8)

        self.filename = filename
        self.data = data.flatten()
        if self.input_source in {'pyramid', 'resizer'}:
            self.check_image_size()
        self.data.tofile(self.filename)

    def generate_data_for_bpu(self):
        filename = os.path.join(arg_dict['local_work_path'],
                                'bpu_input_' + str(self.input_idx))
        if self.input_source == 'ddr':
            filename += '.bin'
        elif self.input_source == 'pyramid':
            if self.is_one_channel():
                filename += '.y'
            else:
                filename += '.yuv'
            if self.image_stride != self.pyramid_stride_in_hbm and (
                    not self.vio_config):
                if self.image_stride == self.valid_dim[2]:
                    pass
                else:
                    if arg_dict['march'].find('bayes') != -1:
                        pass
                    else:
                        logging.critical(
                            'model input image file \'' + self.filename +
                            '\' width (' + str(self.image_stride) +
                            ') does not comply with pyramid input image stride specified when compiling model ('
                            + str(self.pyramid_stride_in_hbm) +
                            ') nor valid input width (' +
                            str(self.valid_dim[2]) +
                            '). Please provide another image with compatible width.'
                        )
                        raise RuntimeError
        elif self.input_source == 'resizer':
            if self.is_one_channel():
                filename += '.y'
            else:
                filename += '.yuv'
        self.data.tofile(filename)
        self.bpu_input_file = filename

    def generate_data_for_predictor(self):
        filename = os.path.join(arg_dict['local_work_path'], 'framework_input_'
                                + str(self.input_idx)) + '.bin'

        if self.input_source == 'ddr':
            self.data.tofile(filename)
        elif self.input_source == 'pyramid':
            self._generate_data_for_predictor_pyramid(filename)
        elif self.input_source == 'resizer':
            self._generate_data_for_predictor_resizer(filename)
        self.pred_input_file = filename

    def _generate_data_for_predictor_pyramid(self, filename):
        if not self.pyramid_ds_factor:
            pass
        else:
            if arg_dict['run_bpu']:
                base_dir = arg_dict['bpu_output_path']
            else:
                base_dir = arg_dict['sim_output_path']
            pym_output_file_find = False
            for file in os.listdir(base_dir):
                if 'pyramid_output_layer' in file:
                    pym_output_file_find = True
                    self.data = np.frombuffer(
                        open(os.path.join(base_dir, file), 'rb').read(),
                        dtype=np.uint8)
                    self.image_shape[0] = int(
                        file[file.find('H') +
                             1:file.find('_', file.find('H'))])
                    self.image_shape[1] = int(
                        file[file.find('W') +
                             1:file.find('.', file.find('W'))])
                    self.stride_speicified_manually = False
                    self.image_stride = self.image_shape[1]
                    break
            if not pym_output_file_find:
                logging.critical('Pyramid output file is not generated!')
                exit(-1)

        if self.image_shape[-1] == 1:
            data = self.data - 128
            data = data.reshape(self.image_shape)
        elif self.image_shape[-1] == 3:
            data = convert_nv12_to_yuv444_int8(self.data, self.image_shape)
        else:
            logging.critical('pyramid input channel number ',
                             self.image_shape[-1], ' is invalid!')
            exit(-1)

        # Remove padding from stride
        if self.stride_speicified_manually:
            data = data[:, :self.image_shape[1], :]

        roi_coord = self.image_roi_coord or (0, 0)
        roi_size = [self.valid_dim[1], self.valid_dim[2]]

        top = roi_coord[0]
        left = roi_coord[1]
        bottom = roi_coord[0] + roi_size[0]
        right = roi_coord[1] + roi_size[1]

        if top < 0 or left < 0 or bottom > self.image_shape[
                0] or right > self.image_shape[1]:
            assert False, 'pyramid ROI is not entirely within the image'
        data = data[top:bottom, left:right, :]
        data.tofile(filename)
        return data

    def _generate_data_for_predictor_resizer(self, filename):
        cmd = 'hbdk-resize '
        cmd += '--march ' + arg_dict['march']
        if self.stride_speicified_manually:
            cmd += ' --src-stride ' + str(self.image_stride)
        if not self.pyramid_ds_factor:
            cmd += ' --src-file ' + self.bpu_input_file
        else:
            if arg_dict['run_bpu']:
                base_dir = arg_dict['bpu_output_path']
            else:
                base_dir = arg_dict['sim_output_path']
            pym_output_file_find = False
            for file in os.listdir(base_dir):
                if 'pyramid_output_layer' in file:
                    pym_output_file_find = True
                    cmd += ' --src-file ' + os.path.join(base_dir, file)
                    self.image_shape[0] = int(
                        file[file.find('H') +
                             1:file.find('_', file.find('H'))])
                    self.image_shape[1] = int(
                        file[file.find('W') +
                             1:file.find('.', file.find('W'))])
            if not pym_output_file_find:
                logging.critical('Pyramid output file is not generated!')
                exit(-1)
        resize_dst = os.path.join(arg_dict['local_work_path'],
                                  'framework_input_' + str(self.input_idx))
        if self.is_one_channel():
            resize_dst += '.y'
        else:
            resize_dst += '.yuv'
        cmd += ' --src-size ' + str(self.image_shape[0]) + 'x' + str(
            self.image_shape[1])
        cmd += ' --dst-size ' + str(self.valid_dim[1]) + 'x' + str(
            self.valid_dim[2])
        cmd += ' --dst-file ' + resize_dst
        cmd += ' --roi-coord ' + str(self.image_roi_coord[0]) + 'x' + str(
            self.image_roi_coord[1])
        cmd += ' --roi-size ' + str(self.image_roi_size[0]) + 'x' + str(
            self.image_roi_size[1])
        out, err, returncode = execute_shell_cmd(cmd)
        if returncode != 0:
            logging.critical('Fail to execute {}'.format(cmd))
            sys.exit(1)
        if out:
            logging.warning(out)
        if err:
            logging.warning(err)
        with open(resize_dst, 'rb') as f:
            data = np.frombuffer(f.read(), dtype=np.uint8)
            if self.image_shape[-1] == 3:
                data = convert_nv12_to_yuv444_int8(data, self.valid_dim[1:])
            elif self.image_shape[-1] == 1:
                data = data - 128
            else:
                logging.critical('resizer input channel number ',
                                 self.image_shape[-1], ' is invalid!')
                exit(-1)
        data.tofile(filename)


input_infos = []  # Type: List[InputInfo]


def check_executable_file(f: str):
    assert f, 'empty file name'
    assert os.path.isfile(f), '%s does not exist' % f
    assert os.access(f, os.X_OK), 'cannot execute %s, no permission?' % f


def check_readable_file(f: str):
    assert f, 'empty file name'
    assert os.path.isfile(f), '%s does not exist' % f
    assert os.access(f, os.R_OK), 'cannot access %s, no permission?' % f


def find_in_current_folder(extension_names, crc32):
    assert isinstance(extension_names, (list, tuple))
    assert crc32 is not None
    files = [f for f in os.listdir('.') if os.path.isfile(f)]
    for f in files:
        ext = f.split('.')[-1]
        if ext in extension_names and os.access(
                f, os.R_OK) and get_file_crc32(f) == crc32:
            return [f]
    return None


### hbm, get a few model infos
def check_hbm(hbm: str):
    check_readable_file(hbm)
    assert hbm.endswith('hbm'), 'HBM should end with ".hbm", but %s' % hbm


def check_executable_or_empty(program: str):
    if program:
        check_executable_file(program)


def check_readable_file_or_empty(f: str):
    if f:
        check_readable_file(f)


def check_readable_multiple_files_or_empty(files: str):
    if files:
        for f in files:
            check_readable_file(f)


def check_readable_multiple_exists_or_empty(files: str):
    if files:
        for f in files:
            assert os.path.exists(f), "%s does not exist" % f


def arg_str_to_bool(v):
    """
    argparse module helper function to convert argument into bool
    """
    if v.lower() in ('yes', 'true', 't', 'y', '1'):
        return True
    if v.lower() in ('no', 'false', 'f', 'n', '0'):
        return False
    raise argparse.ArgumentTypeError('Boolean value expected, but got: ' + v)


def parse_args(print_ok=False):
    if '--version' in sys.argv[1:]:
        print(hbdk_model_verifier._version.__full_version__)
        sys.exit(0)

    parser = argparse.ArgumentParser(
        description=
        "Tool to verify the numerical consistency of deployed model for Horizon BPU.",
        add_help=False)
    add_warning_for_duplidate_arguments(parser)

    parser_type = parser.add_argument_group(
        'Verification type options',
        'Select what result to compare with predictor result')
    parser_model = parser.add_argument_group(
        'Model options', 'HBM, model, param related options')
    parser_input = parser.add_argument_group(
        'Input options', 'Input binary, shape, ROI related options')
    parser_path = parser.add_argument_group(
        'Path options', 'File/Folder Path related options')
    parser_connection = parser.add_argument_group(
        'Connection options', 'Remote connection related options')
    parser_remote = parser.add_argument_group(
        'Remote options', 'Options that affect execution on remote bpu')
    parser_comparison = parser.add_argument_group(
        'Comparison options',
        'Options that affect the result comparison between simulator/bpu and predictor'
    )
    parser_misc = parser.add_argument_group('Misc options', '')

    is_developer = False
    try:
        is_developer = (hbdk.__release_type__ == "dev"
                        ) or socket.gethostname().find('.hochip.cc') != -1
    except Exception:
        pass

    if is_developer:
        parser_dev = parser.add_argument_group('Developer options',
                                               'Developer related options')
    else:
        parser_dev = parser.add_argument_group()

    orig_parser_dev_add_argument = parser_dev.add_argument

    def parser_dev_add_argument(*args, **kwargs):
        if not is_developer:
            kwargs['help'] = argparse.SUPPRESS
        return orig_parser_dev_add_argument(*args, **kwargs)

    parser_dev.add_argument = parser_dev_add_argument

    name_help = (
        ('--hbm', 'hbm containing model to verify', parser_model),
        ('--model-name', 'name of model to verify', parser_model),
        ('--model-json', 'MXNet model json path', parser_model),
        ('--model-param', 'MXNet model param path', parser_model),
        ('--model-pb', 'Tensorflow model protobuf path', parser_model),
        ('--model-pt', 'Pytorch model pt path', parser_model),
        ('--model-input',
         'model input (jpg/png/yuv/y or int8 binary/txt tensor data)',
         parser_input),
        ('--yuv-shape', 'YUV shape for resizer/pyramid, HxW', parser_input),
        ('--vio-config',
         '(optional) VIO config file for pyramid/resizer model', parser_input),
        ('--pyramid-ds-factor',
         '(optional) pyramid down sample factor of input layer', parser_input),
        ('--roi-coord', 'ROI coordinate for resizer/pyramid model, HxW',
         parser_input),
        ('--roi-size', 'ROI size for resizer/pyramid model, HxW',
         parser_input),
        ('--ip', 'IP address of remote BPU', parser_connection),
    )

    name_help_default_type = (
        ('--local-work-path',
         'local path to save temporary data and final results', '.', str,
         parser_path),
        ('--remote-work-path', 'remote bpu path to store temporary data',
         '/userdata', str, parser_path),
        ('--username', 'username to login remote BPU', 'root', str,
         parser_connection),
        ('--password', 'password to login remote BPU', '', str,
         parser_connection),
        ('--port', 'port to login remote BPU', 22, int, parser_connection),
        ('--times', 'Times to run on BPU', 1, int, parser_remote),
        ('--image-stride', 'W stride for resizer/pyramid', None, int,
         parser_input),
    )

    parser_type.add_argument(
        '--skip-bpu',
        help='use simulator instead of bpu execution.',
        action='store_true',
        default=False)
    parser_type.add_argument(
        '--memory',
        help=
        'Specify the max memory usage(unit: MiB) of bpu in simulator. Ignored in non-simulator environment',
        type=int,
        default=None,
    )
    parser_type.add_argument(
        '--force-run-simulator',
        help='run simulator and compare its results as well',
        action='store_true',
        default=False)

    for name, help, parser_group in name_help:
        parser_group.add_argument(name, help=help)

    for name, help, default, type, parser_group in name_help_default_type:
        parser_group.add_argument(
            name,
            help='%s. "%s" by default' % (help, str(default)),
            default=default,
            type=type)

    parser_remote.add_argument(
        '--no-bpu-clean',
        help='Do not clean the files sent to and generated by BPU',
        action='store_true',
        default=False)
    parser_remote.add_argument(
        '--clean-remote-work-path',
        action='store_true',
        help=
        "Clean all model verifier temp files in remote work path before build")
    parser_remote.add_argument(
        '--hbrt-log-level',
        type=int,
        default=0,
        help="The log level for hbrt. More verbose with bigger number,"
        " but may slightly affect the performance")
    parser_remote.add_argument(
        '--env',
        type=str,
        default=[],
        nargs='+',
        help=
        "The additional environment variables for bpu remote execution or simulator."
        " Usage --env A=1 B=2")

    parser_comparison.add_argument(
        '--diff-threshold',
        type=float,
        default=0,
        help=
        "The threshold of difference to compare between predictor result and simulator/bpu."
        " Default is 0. You may increase this to pass the verification, if the floating point"
        " result has slight difference")
    parser_dev.add_argument(
        '--allow-non-output-from-predictor',
        action='store_true',
        help=
        "When some special operator is the model output, Hbdk may optimize them away,"
        " So the final model output is not the same as the predictor. Allow to check against"
        " non output tensors from the predictor result with this option")

    parser_dev.add_argument(
        '--aarch64-run-model-program-path',
        help='Specify an alternate executable to run model',
        default='',
        type=str)
    parser_dev.add_argument(
        '--bpu-timeout',
        help='The timeout when running on bpu. Default is 1000',
        default=1000,
        type=float)
    parser_dev.add_argument(
        '--bpu-lock-local-file-path',
        help=
        'The local file path for flock() to help ensure only one ssh connection to bpu exists. '
        'Useful when running hbdk-model-verifier in parallel.',
        default='',
        type=str)
    parser_dev.add_argument(
        '--memcached-server',
        help=
        'Memcached server for locking. env variable HBDK_MODEL_VERIFIER_MEMCACHED_SERVER is also allowed',
        default='',
        type=str)
    parser_dev.add_argument(
        '--check-consistency',
        help=
        'Check if the output on bpu is the same in every runs. Only useful is --times > 1',
        action='store_true',
        default=False)
    parser_dev.add_argument(
        '--reboot-bpu',
        action='store_true',
        default=False,
        help="Reboot the bpu chip before running the model")
    parser_dev.add_argument(
        '--lock-timeout',
        help="The timeout to acquire lock. Default is 0 (no timeout)",
        default=0,
        type=float)
    parser_dev.add_argument(
        '--stress-args',
        help="The options to the stress program",
        default='',
        type=str)
    parser_dev.add_argument(
        '--upload-exe-dir',
        help=
        "Upload executables and shared libs to remote dir and do nothing else",
        default='',
        type=str)
    parser_dev.add_argument(
        '--test-program',
        help=("Alternate test program on board"),
        default='',
        type=str)
    parser_dev.add_argument(
        '--upload-files',
        help="Files to upload to the working directory",
        default=[],
        nargs="*")
    parser_dev.add_argument(
        '--extra-args', help="Extra arguments to executables", default='')
    parser_dev.add_argument(
        '--gdbserver', help="Argument to gdbserver", default='')
    parser_dev.add_argument(
        '--bpu-then-simulator-fc-inst-index',
        default='',
        help="Run some insts on bpu then run the rest on simulator."
        " Should be two number separated by comma")
    parser_dev.add_argument(
        '--no-random-folder',
        default=False,
        action='store_true',
        help="Do not add random folder to local/remote folder. Use as-is")
    parser_dev.add_argument(
        '--replay-folder',
        default=False,
        action='store_true',
        help="Use the most recent generated folder as the local/remote folder")
    parser_dev.add_argument(
        '--debug-bpu',
        default=False,
        action='store_true',
        help="Enable bpu debug")
    parser_dev.add_argument(
        '--use-exist-pred-output',
        default=False,
        action='store_true',
        help="Use existing predictor output. No run again")
    parser_dev.add_argument(
        '--no-predictor',
        default=False,
        action='store_true',
        help="Disable to run predictor")
    parser_dev.add_argument(
        '--bisect-start', default=None, type=int, help="Bisect start value")
    parser_dev.add_argument(
        '--bisect-step', default=None, type=int, help="Bisect step")
    parser_dev.add_argument(
        '--bisect-min', default=None, type=int, help="Bisect min value")
    parser_dev.add_argument(
        '--bisect-max', default=None, type=int, help="Bisect max value")
    parser_dev.add_argument(
        '--bisect-fail-on-low',
        default=None,
        type=arg_str_to_bool,
        help="Whether bisecting fails when value is decreasing")
    parser_dev.add_argument(
        '--bisect-args',
        default=None,
        type=str,
        help=
        "Bisect program to run, must receive one additional integer as the argument."
        " returncode 0 for success, returncode 125 for skip")
    parser_dev.add_argument(
        '--bisect-tag',
        default=None,
        type=str,
        help="Tag for bisect, to ease parse stdout")
    parser_dev.add_argument(
        '--pmic-tool', action='store_true', help="Upload pmic tool to BPU")
    parser_dev.add_argument('--reference', help='Reference onnx file')

    parser_misc.add_argument(
        '-h', '--help', help='show this help message and exit', action='help')
    parser_misc.add_argument(
        '--verbose',
        help='Show more all stdout/stderr outputs of subprograms called',
        action='store_true',
        default=False)
    parser_misc.add_argument(
        '--version',
        action='version',
        version=hbdk_model_verifier._version.__full_version__)

    iapr = iargparse.InteractiveArgParseResult(parser, print_ok)

    iapr.get_or_ask_until_ok('test_program', checker=check_executable_or_empty)
    iapr.get_or_ask_until_ok('extra_args')

    has_model = True
    if iapr.get('test_program'):
        has_model = False
    has_predictor = True
    if iapr.get('no_predictor'):
        has_predictor = False

    if iapr.get('upload_exe_dir'):
        check_hbdk_tool_existence()
        dev_upload_exe_to_bpu_board(
            iapr.get('upload_exe_dir'), iapr.get_or_ask_until_ok('ip'))
        sys.exit(0)

    if has_model:
        iapr.get_or_ask_until_ok('hbm', checker=check_hbm)
        model_infos = parse_hbm_to_json(iapr.get('hbm'))

        ### model name, get 1 model info
        model_names = [d['model name'] for d in model_infos]

    def check_model_name(model_name):
        assert model_name, 'empty model name'
        assert model_name in model_names, \
            'invalid model name, must be one of the following:\n%s' % '\n'.join(model_names)

    is_mxnet_model = False
    if has_model:
        iapr.get_or_ask_until_ok(
            'model_name', choices=model_names, checker=check_model_name)
        model_info = [
            d for d in model_infos if d['model name'] == iapr.get('model_name')
        ][0]
        is_mxnet_model = 'param file' in model_info

    has_vio = [False]

    predictor_framework = None

    if has_model and has_predictor:
        ### json + param, or pb
        if is_mxnet_model:

            def check_json(json):
                check_readable_file(json)
                if get_file_crc32(json) != model_info['model file crc32']:
                    logging.warning(
                        'The model was compiled with json CRC32 %X, but provided json is %X'
                        % (model_info['model file crc32'],
                           get_file_crc32(json)))

            choices = None
            if iapr.get('model_json') is None:
                choices = find_in_current_folder(
                    ['json'], model_info['model file crc32'])
            iapr.get_or_ask_until_ok(
                'model_json', choices=choices, checker=check_json)

            def check_param(param):
                check_readable_file(param)
                if get_file_crc32(param) != model_info['param file crc32']:
                    logging.warning(
                        'The model was compiled with param CRC32 %X, but provided param is %X'
                        % (model_info['param file crc32'],
                           get_file_crc32(param)))

            choices = None
            if iapr.get('model_param') is None:
                choices = find_in_current_folder(
                    ['param', 'params'], model_info['param file crc32'])
            iapr.get_or_ask_until_ok(
                'model_param', choices=choices, checker=check_param)
        else:
            if iapr.get('model_pb') is None and iapr.get('model_pt') is None:
                logging.critical(
                    'Please specify model file by either --model-pb for tensorflow model or --model-pt '
                    'for pytorch model')
                raise RuntimeError

            if iapr.get('model_pb') is not None and iapr.get(
                    'model_pt') is not None:
                logging.critical('Please specify only one model file')
                raise RuntimeError

            def check_pb(pb):
                check_readable_file(pb)
                if get_file_crc32(pb) != model_info['model file crc32']:
                    logging.warning(
                        'The model was compiled with pb CRC32 %X, but provided pb is %X'
                        % (model_info['model file crc32'], get_file_crc32(pb)))

            if iapr.get('model_pt') is not None:
                predictor_framework = 'pytorch'
                # hbm only record hbir crc32 for torch model
                # check_pb(iapr.get('model_pt'))

            if iapr.get('model_pb') is not None:
                predictor_framework = 'tensorflow'
                check_pb(iapr.get('model_pb'))

            #iapr.get_or_ask_until_ok('model_pb', checker=check_pb)

        ### model input
        input_number = len(model_info['input features'])
        assert input_number > 0, 'invalid input number %d' % input_number
        sep_const_str = 's, separated by comma' if input_number > 1 else ''
        is_resizer_or_pyramid = [
            x['input source'].lower() in ('resizer', 'pyramid')
            for x in model_info['input features']
        ]

        # if is_resizer_or_pyramid.count(True) > 1:
        #     print('currently max 1 resizer/pyramid input is supported')
        #     sys.exit(1)

        def check_input_data(input_data_file_names):
            assert input_data_file_names, 'empty input file name(s)'
            assert len(input_data_file_names.split(',')) == input_number, \
                'must specify exactly %d model input file%s, but %s' % (
                    input_number, sep_const_str, input_data_file_names)

            for i, f in enumerate(input_data_file_names.split(',')):
                check_readable_file(f)
                ext = f.split('.')[-1].lower()
                is_image = ext in supported_image_ext

                # pyramid/resizer need image, DDR needs non image
                assert is_image == is_resizer_or_pyramid[i], \
                    'input %d is from %s, but %s is %s' % (
                        i, model_info['input features'][i]['input source'].lower(), f,
                        'image' if is_image else 'not image')

        if iapr.get('model_input') is not None:
            check_input_data(iapr.get('model_input'))

        is_resizer = [
            x['input source'].lower() == 'resizer'
            for x in model_info['input features']
        ]
        is_pyramid = [
            x['input source'].lower() == 'pyramid'
            for x in model_info['input features']
        ]

        if not any(is_resizer_or_pyramid):
            if iapr.get('roi_coord') is not None:
                logging.warning(
                    'no resizer or pyramid input for this model, ignore --roi-coord'
                )
            if iapr.get('roi_size') is not None:
                logging.warning(
                    'no resizer or pyramid input for this model, ignore --roi-size'
                )
        else:

            def check_roi_coord(roi_coord):
                assert roi_coord, 'empty ROI coordinate'
                assert len(roi_coord.split(',')) == input_number, \
                    '--roi-coord should have %d coordinate%s' % (input_number, sep_const_str)

                for i, coord in enumerate(roi_coord.split(',')):
                    if not is_resizer_or_pyramid[i]:
                        assert coord == '', 'input %d is not resizer or pyramid, should have empty ROI coord, but %s' % (
                            i, coord)
                        continue

                    assert len(coord.split(
                        'x')) == 2, 'coord should be HxW, but %s' % coord

            roi_coord = iapr.get('roi_coord')
            if roi_coord:
                check_roi_coord(roi_coord)

            def check_roi_size(roi_size):
                assert roi_size, 'empty ROI size'
                assert len(roi_size.split(',')) == input_number, \
                    '--roi-size should have %d size%s' % (input_number, sep_const_str)

                for i, size in enumerate(roi_size.split(',')):
                    if not is_resizer_or_pyramid[i]:
                        assert size == '', 'input %d is not resizer or pyramid, should have empty ROI size, but %s' % (
                            i, size)
                        continue

                    assert len(size.split(
                        'x')) == 2, 'size should be HxW, but %s' % size
                    h, w = [int(x) for x in size.split('x')]
                    feature_info = model_info['input features'][i]
                    if is_resizer[i]:
                        h_alignment = feature_info[
                            'resizer ROI height alignment']
                        w_alignment = feature_info[
                            'resizer ROI width alignment']
                        if h % h_alignment:
                            logging.warning(
                                'input %d ROI height should be a multiple of %d, but %d'
                                % (i, h_alignment, h))
                        if w % w_alignment:
                            logging.warning(
                                'input %d ROI width swould be a multiple of %d, but %d'
                                % (i, w_alignment, w))

            roi_size = iapr.get('roi_size')
            if roi_size:
                check_roi_size(roi_size)

        if iapr.get('model_input') is not None:
            is_y = [
                x.split('.')[-1].lower() in ('y')
                for x in iapr.get('model_input').split(',')
            ]
            is_yuv_or_y = [
                x.split('.')[-1].lower() in ('y', 'yuv')
                for x in iapr.get('model_input').split(',')
            ]
            if not any(is_yuv_or_y):
                if iapr.get('yuv_shape') is not None:
                    logging.warning(
                        'no gray or YUV input for this model, ignore --yuv-shape'
                    )
            else:

                def check_yuv_shape(yuv_shape):
                    assert yuv_shape, 'empty YUV shape'
                    assert len(yuv_shape.split(',')) == input_number, \
                        '--yuv-shape should have %d shape%s' % (input_number, sep_const_str)

                    for i, shape in enumerate(yuv_shape.split(',')):
                        if not is_yuv_or_y[i]:
                            assert shape == '', 'input %d is not YUV, should have no shape, but %s' % (
                                i, shape)
                            continue

                        assert len(shape.split(
                            'x')) == 2, 'shape should be HxW, but %s' % shape
                        h, w = [int(x) for x in shape.split('x')]

                        yuv_file_name = iapr.get('model_input').split(',')[i]
                        stride = iapr.get('image_stride')
                        if not stride:
                            stride = (w + 15) // 16 * 16
                        else:
                            stride = int(stride)
                        yuv_data_contain_stride = bool(
                            iapr.get('image_stride'))
                        check_readable_file(yuv_file_name)
                        yuv_file_size = os.path.getsize(yuv_file_name)
                        if yuv_data_contain_stride:
                            shape = (h, stride)
                            filesize_gray = h * stride
                            filesize_yuv = h * stride + ((h + 1) // 2) * (
                                (stride + 1) // 2) * 2
                        else:
                            shape = (h, w)
                            filesize_gray = h * w
                            filesize_yuv = h * w + ((h + 1) // 2) * (
                                (w + 1) // 2) * 2
                        assert yuv_file_size in (filesize_gray, filesize_yuv), '%s shape is not %s ' % (
                            yuv_file_name, shape) \
                                                                               + 'expect file size of %d for gray image or %d for YUV Image, but %d' % (
                                                                                   filesize_gray, filesize_yuv,
                                                                                   yuv_file_size)

                iapr.get_or_ask_until_ok('yuv_shape', checker=check_yuv_shape)
                iapr.get_or_ask_until_ok('image_stride')

        ### VIO, optional for resizer/pyramid
        if not any(is_resizer_or_pyramid):
            if iapr.get('vio_config') is not None:
                logging.warning(
                    'no resizer/pyramid input for this model, ignore --vio-config'
                )
            has_vio = [False] * input_number
        else:
            pass

        def check_vio_config(vio_config):
            support_vio_march = [
                'bernoulli',
                'x2',
            ]
            if has_model:
                if support_vio_march.count(model_info['march'].lower()) == 0:
                    raise RuntimeError(
                        "Using vio in model verifier is only supported on bernoulli march. "
                        "For %s please dump vio data to feed in model verifier."
                        % (model_info['march']))
            assert len(vio_config.split(',')) == input_number, \
                '--vio-config should have %d config%s' % (input_number, sep_const_str)
            if vio_config.strip() == '':
                return  # allow empty string, no VIO

            for i, config in enumerate(vio_config.split(',')):
                if not is_resizer_or_pyramid[i]:
                    assert config == '', 'input %d is not resizer/pyramid, should not have VIO config, but %s' % (
                        i, config)
                    continue

                check_readable_file(config)
                assert config.endswith(
                    '.json'
                ), 'VIO config should be a json file, but %s' % config

        if iapr.get('vio_config') is None:
            has_vio = [False]
        else:
            check_vio_config(iapr.get('vio_config'))
            has_vio = [x != '' for x in iapr.get('vio_config')]
        ### pyramid downscale factor, one for each VIO
        if not any(has_vio):
            if iapr.get('pyramid_ds_factor') is not None:
                logging.warning(
                    'no VIO for this model, ignore --pyramid-ds-factor')
        else:

            def check_pyramid_ds_factor(pyramid_ds_factor):
                assert len(pyramid_ds_factor.split(',')) == input_number, \
                    '--pyramid-ds-factor should have %d factor%s' % (input_number, sep_const_str)

                for i, factor in enumerate(pyramid_ds_factor.split(',')):
                    if not has_vio[i]:
                        assert factor == '', \
                            'input %d has no VIO config, should not have pyramid downscale factor, but %s' % (i, factor)
                        continue

                    valid_ds_factors = (1, 2, 4, 8, 16, 32)
                    assert int(factor) in valid_ds_factors, \
                        'invalid pyramid downscale factor %s, should be one of %s' % (factor, str(valid_ds_factors))

            iapr.get_or_ask_until_ok(
                'pyramid_ds_factor', checker=check_pyramid_ds_factor)
            if iapr.get('image_stride'):
                logging.warning(
                    'image-stride is ignored when VIO module is enabled.')

    if not iapr.get('skip_bpu') and not iapr.get('ip'):
        iapr.get_or_ask_until_ok(
            'skip_bpu', choices=[True, False], ignore_default=True)

    ### BPU board
    if iapr.get('skip_bpu'):
        if iapr.get('ip') is not None:
            logging.warning('BPU is skipped (--skip-bpu), ignore --ip')
        if iapr.get('username') != 'root':
            logging.warning('BPU is skipped (--skip-bpu), ignore --username')
        if iapr.get('password') != '':
            logging.warning('BPU is skipped (--skip-bpu), ignore --password')
        if iapr.get('port') != 22:
            logging.warning('BPU is skipped (--skip-bpu), ignore --port')
        if iapr.get('remote_work_path') != '/userdata':
            logging.warning(
                'BPU is skipped (--skip-bpu), ignore --remote-work-path')
        if iapr.get('times') != 1:
            logging.warning('BPU is skipped (--skip-bpu), ignore --times')
        if iapr.get('check_consistency') != False:
            logging.warning(
                'BPU is skipped (--skip-bpu), ignore --check-consistency')
        if iapr.get('no_bpu_clean') != False:
            logging.warning(
                'BPU is skipped (--skip-bpu), ignore --no_bpu_clean')
        if iapr.get('bpu_timeout'):
            logging.warning(
                'BPU is skipped (--skip-bpu), ignore --bpu-timeout')
        if iapr.get('bpu_lock_local_file_path'):
            logging.warning(
                'BPU is skipped (--skip-bpu), ignore --bpu-lock-local-file-path'
            )
        if iapr.get('aarch64_run_model_program_path'):
            logging.warning(
                'BPU is skipped (--skip-bpu), ignore --aarch64-run-model-program-path'
            )
        if iapr.get('clean_remote_work_path'):
            logging.warning(
                'bpu is skipped (--skip-bpu), ignore --clean-remote-work-path')
        if iapr.get('reboot_bpu'):
            logging.warning('BPU is skipped (--skip-bpu), ignore --reboot-bpu')
        if iapr.get('upload_files'):
            logging.warning(
                'BPU is skipped (--skip-bpu), ignore --upload-files')
    else:

        def check_ip(ip):
            assert ip, 'empty IP string'
            ip_digits = ip.split('.')
            assert len(ip_digits) == 4, '%s is not a valid IP address' % ip
            for num in ip_digits:
                try:
                    ip_entry = int(num)
                except ValueError:
                    assert False, '%s is not a valid IP address' % ip
                assert 0 <= ip_entry <= 255, '%s is not a valid IP address' % ip

        iapr.get_or_ask_until_ok('ip', checker=check_ip)

        def check_port(port):
            assert 1 <= port <= 65535, "%d is not a valid port" % port

        iapr.get_or_ask_until_ok('port', checker=check_port)

        def check_times(times):
            assert 1 <= times and int(
                times) == times, "%d is not a valid times" % times

        iapr.get_or_ask_until_ok('times', checker=check_times)

        iapr.get_or_ask_until_ok('check_consistency', choices=[True, False])
        iapr.get_or_ask_until_ok('no_bpu_clean', choices=[True, False])
        iapr.get_or_ask_until_ok('bpu_timeout')
        iapr.get_or_ask_until_ok('bpu_lock_local_file_path')
        iapr.get_or_ask_until_ok('aarch64_run_model_program_path')
        iapr.get_or_ask_until_ok(
            'clean_remote_work_path', choices=[True, False])
        iapr.get_or_ask_until_ok('reboot_bpu')
        iapr.get_or_ask_until_ok(
            'upload_files', checker=check_readable_multiple_exists_or_empty)
        if iapr.get('memory'):
            logging.warning('Simulator not used , ignore --memory')

    def check_env(envs):
        if not envs:
            return
        s = "HBDK VERIFIER ENV OK"
        returncode = 255
        try:
            args = ['/usr/bin/env'] + envs
            returncode = subprocess.call(
                args, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        except (OSError, subprocess.SubprocessError,
                subprocess.CalledProcessError) as e:
            pass
        if returncode != 0:
            assert False, "Invalid arguments to --env: %s, should be in the format of NAME=value" % ' '.join(
                envs)

    iapr.get_or_ask_until_ok('hbrt_log_level')
    iapr.get_or_ask_until_ok('env', checker=check_env)

    ### local directory
    def check_local_work_path(local_work_path):
        assert local_work_path, 'empty local work path'
        assert os.path.isdir(
            local_work_path), '%s is not a directory' % local_work_path
        assert os.access(
            local_work_path,
            os.W_OK), '%s is not writable, no permission?' % local_work_path

    iapr.get_or_ask_until_ok('local_work_path', checker=check_local_work_path)
    iapr.get_or_ask_until_ok('lock_timeout')
    iapr.get_or_ask_until_ok('stress_args')

    def check_non_negative(num):
        assert float(
            num) >= 0, 'Provided number must be non-negative' % str(num)

    iapr.get_or_ask_until_ok('diff_threshold', checker=check_non_negative)
    iapr.get_or_ask_until_ok('allow_non_output_from_predictor')

    ########################################################
    # update result, so that other functions need no change
    result = dict()
    if has_model:
        result['hbm_path'] = os.path.abspath(iapr.get('hbm'))
        result['hbm_filename'] = os.path.basename(iapr.get('hbm'))
        result['model_name'] = iapr.get('model_name')
        result['model_info'] = model_info
        result['march'] = model_info['march']
    result['verbose'] = iapr.get('verbose')
    result['lock_timeout'] = iapr.get('lock_timeout')
    result['stress_args'] = iapr.get('stress_args')
    result['diff_threshold'] = iapr.get('diff_threshold')
    result['allow_non_output_from_predictor'] = iapr.get(
        'allow_non_output_from_predictor')
    result['env'] = iapr.get('env')
    result['test_program'] = iapr.get('test_program')
    result['extra_args'] = iapr.get('extra_args')
    result['debug_bpu'] = iapr.get('debug_bpu')
    result['use_exist_pred_output'] = iapr.get('use_exist_pred_output')
    result['bisect_start'] = iapr.get('bisect_start')
    result['bisect_min'] = iapr.get('bisect_min')
    result['bisect_max'] = iapr.get('bisect_max')
    result['bisect_step'] = iapr.get('bisect_step')
    result['bisect_fail_on_low'] = iapr.get('bisect_fail_on_low')
    result['bisect_args'] = iapr.get('bisect_args')
    result['bisect_tag'] = iapr.get('bisect_tag')
    result['pmic_tool'] = iapr.get('pmic_tool')
    reference = iapr.get('reference')
    result['reference'] = reference and os.path.abspath(reference) or None

    bisect_stuffs = [
        result['bisect_start'], result['bisect_min'], result['bisect_max'],
        result['bisect_step'], result['bisect_args'],
        result['bisect_fail_on_low'], result['bisect_tag']
    ]

    if any([x is not None for x in bisect_stuffs
            ]) and (not all([x is not None for x in bisect_stuffs])):
        raise argparse.ArgumentTypeError(
            'All of --bisect-start, --bisect-min, --bisect-max,'
            ' --bisect-step, --bisect-args, --bisect-fail-on-low, '
            '--bisect-tag must be specified,'
            ' if any one of them are specified')

    if not result['debug_bpu'] and result['extra_args'].find(
            '--dev-locate-problematics-insts') != -1:
        logging.warning(
            '--dev-locate-problematic-insts specified. Enable --debug-bpu')
        result['debug_bpu'] = True
    result['gdbserver'] = iapr.get('gdbserver')
    result['no_random_folder'] = iapr.get('no_random_folder')
    result['replay_folder'] = iapr.get('replay_folder')

    if has_model:
        if has_predictor:
            if is_mxnet_model:
                result['framework'] = 'mxnet'
                result['model_json'] = os.path.abspath(iapr.get('model_json'))
                result['model_param'] = os.path.abspath(
                    iapr.get('model_param'))
            else:
                result['framework'] = predictor_framework
                if predictor_framework == 'tensorflow':
                    result['model_pb'] = os.path.abspath(iapr.get('model_pb'))
                elif predictor_framework == 'pytorch':
                    result['model_pt'] = os.path.abspath(iapr.get('model_pt'))

        input_files = None
        result['input_is_given'] = False
        if iapr.get('model_input') is not None:
            input_files = [
                os.path.abspath(x) for x in iapr.get('model_input').split(',')
            ]
            if len(input_files) != len(model_info['input features']):
                logging.critical('input file number ' + str(len(input_files)) +
                                 ' != ' + ' model input tensor number ' +
                                 str(len(model_info['input features'])) +
                                 ', please check --model-input argument.')
                exit(-1)
            result['input_is_given'] = True

        for idx in range(len(model_info['input features'])):
            feature_info = model_info['input features'][idx]
            feature_name = feature_info['feature name']
            element_type_name = feature_info['element type name']
            input_source = feature_info['input source']
            valid_dim = feature_info['valid dim']
            pyramid_stride = feature_info.get('pyramid stride', None)
            definer = feature_info.get('definer', None)
            roi_coord = None
            roi_size = None
            image_stride = int(
                iapr.get('image_stride')) if iapr.get('image_stride') else None
            input_file = None
            if input_files is not None:
                input_file = input_files[idx]
            if input_file is not None:
                ext = input_file.split('.')[-1]
            else:
                ext = None
            image_shape = None

            if input_source in ('pyramid', 'resizer'):
                # Currently only support one pyramid/resizer input
                if iapr.get('roi_coord'):
                    roi_coord = shape_arg_to_tuple_list(
                        iapr.get('roi_coord'))[0]
                else:
                    roi_coord = (0, 0)
                if iapr.get('roi_size'):
                    roi_size = shape_arg_to_tuple_list(iapr.get('roi_size'))[0]
                else:
                    roi_size = (valid_dim[1], valid_dim[2])
                image_stride = image_stride
                if ext in ('y', 'yuv'):
                    image_shape_str = iapr.get('yuv_shape').split(',')[idx]
                    image_shape = list(
                        shape_arg_to_tuple_list(image_shape_str)[0])
                    if ext == 'y':
                        image_shape.append(1)
                    else:
                        image_shape.append(3)
            vio_config = None
            pyramid_ds_factor = None
            if input_source == 'pyramid' or input_source == 'resizer':
                if any(has_vio):
                    index = has_vio.index(True)
                    vio_config = os.path.abspath(
                        iapr.get('vio_config').split(',')[index])
                    pyramid_ds_factor = int(
                        iapr.get('pyramid_ds_factor').split(',')[index])
            input_info = InputInfo(
                input_idx=idx,
                feature_name=feature_name,
                filename=input_file,
                valid_dim=valid_dim,
                input_source=input_source,
                image_shape=image_shape,
                pyramid_stride_in_hbm=pyramid_stride,
                image_stride=image_stride,
                image_roi_coord=roi_coord,
                image_roi_size=roi_size,
                element_type_name=element_type_name,
                vio_config=vio_config,
                pyramid_ds_factor=pyramid_ds_factor,
                definer=definer,
            )
            input_infos.append(input_info)

    result['skip_bpu'] = iapr.get('skip_bpu')
    if iapr.get('skip_bpu'):
        result['run_bpu'] = False
        result['run_sim'] = True
        result['check_consistency'] = iapr.get('check_consistency')
        result['times'] = iapr.get('times')
        result['remote_work_path'] = None
        result['aarch64_run_model_program_path'] = None
        result['bpu_lock_local_file_path'] = None
        result['upload_files'] = []
        result['memory'] = iapr.get('memory')
    else:
        result['run_bpu'] = True
        result['run_sim'] = False
        result['ip'] = iapr.get('ip')
        result['port'] = iapr.get('port')
        result['username'] = iapr.get('username')
        result['password'] = iapr.get('password')
        result['remote_work_path'] = iapr.get('remote_work_path')
        result['times'] = iapr.get('times')
        result['check_consistency'] = iapr.get('check_consistency')
        result['no_bpu_clean'] = iapr.get('no_bpu_clean')
        result['bpu_timeout'] = iapr.get('bpu_timeout')
        result['bpu_lock_local_file_path'] = iapr.get(
            'bpu_lock_local_file_path')
        result['aarch64_run_model_program_path'] = iapr.get(
            'aarch64_run_model_program_path')
        result['clean_remote_work_path'] = iapr.get('clean_remote_work_path')
        result['reboot_bpu'] = iapr.get('reboot_bpu')
        result['upload_files'] = iapr.get('upload_files')
        result['memory'] = None
    result['bpu_then_simulator_fc_inst_index'] = iapr.get(
        'bpu_then_simulator_fc_inst_index')
    result['hbrt_log_level'] = iapr.get('hbrt_log_level')
    result['memcached_server'] = iapr.get('memcached_server')
    if not result['memcached_server'] and os.environ.get(
            'HBDK_MODEL_VERIFIER_MEMCACHED_SERVER'):
        result['memcached_server'] = os.environ.get(
            'HBDK_MODEL_VERIFIER_MEMCACHED_SERVER')
    if result['pmic_tool']:
        pmic_tool_path = os.path.realpath(
            os.path.join(
                os.path.dirname(hbdk.__file__), 'internal', 'pmic_tool'))
        if result['upload_files']:
            result['upload_files'].append(pmic_tool_path)
        else:
            result['upload_files'] = [pmic_tool_path]

    if iapr.get('force_run_simulator'):
        result['run_sim'] = True
    if iapr.get('bpu_then_simulator_fc_inst_index'):
        result['run_sim'] = True

    now_time = datetime.datetime.now()
    time_str = datetime.datetime.strftime(now_time, '%m%d%H%M%S')
    local_work_path = os.path.abspath(iapr.get('local_work_path'))
    random_path_prefix = 'hbmv_'
    if not result['no_random_folder']:
        if result['replay_folder']:
            mtime = 0
            replay_path = None
            for f in os.listdir(local_work_path):
                folder_path = os.path.join(local_work_path, f)
                if os.path.isdir(folder_path) and f.startswith(random_path_prefix) \
                        and os.path.getmtime(folder_path) > mtime:
                    mtime = os.path.getmtime(folder_path)
                    replay_path = folder_path
            if not replay_path:
                raise RuntimeError(
                    "Found no folders begins with {} under {}".format(
                        random_path_prefix, local_work_path))
            local_work_path = replay_path
        else:
            local_work_path = tempfile.mkdtemp(
                prefix=random_path_prefix,
                suffix='_' + time_str,
                dir=local_work_path)
    result['local_work_path'] = local_work_path

    result['pred_output_path'] = os.path.join(local_work_path,
                                              'framework_output')
    os.makedirs(os.path.join(result['pred_output_path']), exist_ok=True)

    if result['run_sim']:
        result['sim_output_path'] = os.path.join(local_work_path,
                                                 'simulator_output')
        os.makedirs(os.path.join(result['sim_output_path']), exist_ok=True)

    if result['no_random_folder'] and os.path.abspath(
            result['remote_work_path']) == "/userdata":
        assert False, "Must speicify remote work path when no_random_folder specified"
    result['remote_work_root'] = result['remote_work_path']
    if result['run_bpu'] and not result['no_random_folder']:
        result['remote_work_path'] = os.path.join(
            result['remote_work_path'], os.path.basename(local_work_path))

    if not result['aarch64_run_model_program_path']:
        result['aarch64_run_model_program_path'] = os.path.join(
            os.path.dirname(hbdk.__file__), 'sbin', 'hbdk-run-model-aarch64')

    result['x86_run_model_program_path'] = os.path.join(
        os.path.dirname(hbdk.__file__), 'sbin', 'hbdk-run-model-x86')
    if iapr.ever_ask():
        print(
            '\n\n\nYou can use the following command to repeat this verify:\n\n%s %s\n\n'
            % (sys.argv[0], iapr.restore_string()))

    result['has_model'] = has_model
    result['has_predictor'] = has_predictor
    result['is_developer'] = is_developer
    logging.info('======> Parse cmd done')
    return result


def check_hbdk_tool_existence():
    logging.info('======> Check HBDK tool existence')
    tool_list = ['hbdk-config', 'hbdk-disas', 'hbdk-cc']
    for tool in tool_list:
        tool_abspath = shutil.which(tool)
        if not tool_abspath:
            logging.critical(
                'cmd tool ' + tool +
                ' is not installed in your environment. Please check if '
                'hbdk is properly installed.')
            sys.exit(1)
    try:
        cmd = 'hbdk-cc --version'
        out, err, returncode = execute_shell_cmd(cmd)
        if returncode != 0:
            logging.critical('Fail to execute {}'.format(cmd))
            sys.exit(1)
        if out.find('runtime version: ') != -1:
            version_key = 'runtime version: '
        else:
            version_key = 'version: '
        version_index = out.find(version_key) + len(version_key)
        version_index_end = out.find('\n', version_index)
        tool_version = out[version_index:version_index_end]
        arg_dict['hbdk_runtime_version'] = tool_version
    except Exception:
        traceback.print_exc()
        logging.critical('can not get hbdk version by hbdk-cc --version!')
        sys.exit(1)
    try:
        cmd = 'hbdk-config --aarch64-link-dir'
        out, err, returncode = execute_shell_cmd(cmd)
        if returncode != 0:
            logging.critical('Fail to execute {}'.format(cmd))
            sys.exit(1)
        aarch_64_so = os.path.join(out.strip(), 'libhbrt_bernoulli_aarch64.so')
        arg_dict['aarch64_so_path'] = os.path.realpath(aarch_64_so)
        arg_dict['aarch64_hook_so_path'] = os.path.realpath(
            os.path.join(out.strip(), 'libhbrt_bernoulli_aarch64_hook.so'))
        cmd = 'hbdk-config --x86-sim-link-dir'
        out, err, returncode = execute_shell_cmd(cmd)
        if returncode != 0:
            logging.critical('Fail to execute {}'.format(cmd))
            sys.exit(1)
        arg_dict['x86_hook_so_path'] = os.path.join(
            out.strip(), 'libhbrt_bernoulli_x86_hook.so')
    except Exception:
        traceback.print_exc()
        logging.critical('can not get hbdk version by hbdk-cc --version!')
        sys.exit(1)
    logging.info('======> HBDK tools all detected')


def generate_random_input_files():
    for info in input_infos:
        logging.info("generate random binary for input: " + info.feature_name)
        info.generate_random_input_file()


def preprocess_bpu_input_data():
    logging.info('======> Preprocess BPU Input Data')

    for input_info in input_infos:
        try:
            input_info.generate_data_for_bpu()
        except Exception:
            traceback.print_exc()
            logging.critical('convert model input file ' +
                             input_info.filename + ' for bpu failed!')
            sys.exit(1)
    logging.info('======> Preprocess BPU Input Data Done')


def preprocess_framework_input_data():
    logging.info('======> Preprocess Framework Input Data')

    for input_info in input_infos:  # Type: InputInfo
        try:
            input_info.generate_data_for_predictor()
        except Exception:
            traceback.print_exc()
            logging.critical('convert model input file ' +
                             input_info.filename + ' for framework failed!')
            sys.exit(1)

    logging.info('======> Preprocess Framework Input Data Done')


def get_arg_from_input(arg_str, func_to_get_more_arg):
    s = ''
    is_empty_arg = True
    for input_info in input_infos:
        this = func_to_get_more_arg(input_info)
        if this:
            is_empty_arg = False
            s += this
        s += ','
    if s:
        s = s[0:-1]
    if is_empty_arg:
        return ''
    else:
        return arg_str + ' ' + s


def gen_run_cmd_param(for_sim,
                      force_dump_snapshot=False,
                      enable_debugging=True):
    res = 'export HBRT_LOG_LEVEL=%s && ' % str(arg_dict['hbrt_log_level'])
    if not arg_dict['gdbserver']:
        res += 'env ' + ' '.join([shlex.quote(x) for x in arg_dict['env']])
    else:
        res += 'gdbserver --wrapper env ' + ' '.join(
            [shlex.quote(x) for x in arg_dict['env']])
    if arg_dict['debug_bpu']:
        if for_sim:
            res += ' HBRT_MEMORY_PROTECT=false LD_PRELOAD=%s' % arg_dict[
                'x86_hook_so_path']
        else:
            res += ' HBRT_MEMORY_PROTECT=false LD_PRELOAD=./%s' % os.path.basename(
                arg_dict['aarch64_hook_so_path'])
    if not arg_dict['gdbserver']:
        res += ' '
    else:
        res += ' -- ' + arg_dict['gdbserver'] + ' '
    if arg_dict['test_program']:
        if for_sim:
            res += os.path.abspath(arg_dict['test_program'])
        else:
            res += os.path.join('.',
                                os.path.basename(arg_dict['test_program']))
    else:
        if for_sim:
            res += arg_dict['x86_run_model_program_path']
        else:
            res += "./hbdk-run-model-aarch64"

    try:
        if arg_dict['has_model']:
            res += ' -i '
            for input_info in input_infos:
                if for_sim:
                    res += input_info.bpu_input_file + ','
                else:
                    res += (os.path.basename(input_info.bpu_input_file) + ',')
            res = res[0:-1]
            if for_sim:
                res += (' -f ' + arg_dict['hbm_path'])
            else:
                res += (' -f ' + arg_dict['hbm_filename'])
            res += (' -n ' + arg_dict['model_name'])
            res += get_arg_from_input(
                ' --yuv-img-size', lambda info: (str(info.image_shape[0]) + 'x'
                                                 + str(info.image_shape[1]))
                if info.image_shape else '')
            res += get_arg_from_input(
                ' --yuv-stride', lambda info: str(info.image_stride) if info.
                image_stride and info.stride_speicified_manually else '')
            res += get_arg_from_input(
                ' -d', lambda info: (str(info.image_roi_coord[0]) + 'x' + str(
                    info.image_roi_coord[1])) if info.image_roi_coord else '')
            res += get_arg_from_input(
                ' -z', lambda info: (str(info.image_roi_size[0]) + 'x' + str(
                    info.image_roi_size[1])) if info.image_roi_size else '')
            res += get_arg_from_input(
                ' -p', lambda info: str(info.pyramid_ds_factor)
                if info.pyramid_ds_factor else '')
            res += get_arg_from_input(
                ' -v', lambda info: str(
                    info.vio_config if for_sim else os.path.basename(
                        info.vio_config)) if info.vio_config else '')
            if arg_dict['memory']:
                res += ' --memory ' + str(arg_dict['memory'])
            if for_sim:
                res += (' -o ' + arg_dict['sim_output_path'])
            else:
                res += (' -o ' + arg_dict['bpu_output_path'])
            if enable_debugging and arg_dict[
                    'bpu_then_simulator_fc_inst_index']:
                if for_sim:
                    if force_dump_snapshot:
                        os.makedirs(
                            os.path.join(arg_dict['local_work_path'],
                                         'bpu_debug'),
                            exist_ok=True)
                        res += ' --dev-dump-bpu-region {} --dev-dump-sram {} --dev-stop-before-fc-inst-index {}'.format(
                            os.path.join(arg_dict['local_work_path'],
                                         'bpu_debug', 'bpu_region.bin'),
                            os.path.join(arg_dict['local_work_path'],
                                         'bpu_debug', 'sram.bin'),
                            arg_dict['bpu_then_simulator_fc_inst_index'])
                    else:
                        res += ' --dev-restore-bpu-region {} --dev-restore-sram {} --dev-start-since-fc-inst-index {}'.format(
                            os.path.join(arg_dict['local_work_path'],
                                         'bpu_debug', 'bpu_region.bin'),
                            os.path.join(arg_dict['local_work_path'],
                                         'bpu_debug', 'sram.bin'),
                            arg_dict['bpu_then_simulator_fc_inst_index'])
                else:
                    res += ' --dev-dump-bpu-region {} --dev-dump-sram {} --dev-stop-before-fc-inst-index {}'.format(
                        os.path.join(arg_dict['remote_work_path'], 'bpu_debug',
                                     'bpu_region.bin'),
                        os.path.join(arg_dict['remote_work_path'], 'bpu_debug',
                                     'sram.bin'),
                        arg_dict['bpu_then_simulator_fc_inst_index'])
            if arg_dict['check_consistency']:
                res += ' -b'
            if arg_dict['times'] != 1:
                res += ' --dev-times %d' % arg_dict['times']
            if (not for_sim) and arg_dict['reboot_bpu']:
                res += ' --reboot-bpu'
        if arg_dict['extra_args']:
            if for_sim:
                res += ' ' + arg_dict['extra_args'].replace(
                    '{output}', arg_dict['sim_output_path'])
            else:
                res += ' ' + arg_dict['extra_args'].replace(
                    '{output}', arg_dict['bpu_output_path'])
    except Exception:
        traceback.print_exc()
        logging.critical('can not generate cmd parameters from arg dict!')
        sys.exit(1)
    return res


def gen_run_framework_pred_cmd_param():
    res = ' -s '
    try:
        for input_info in input_infos:
            shape = input_info.valid_dim
            if input_info.definer == "OUTPUT_BY_DETECTION_POST_PROCESS":
                res += '1x' + str(shape[2] - 1) + 'x4' + ','
            else:
                res += str(shape[0]) + 'x' + str(shape[1]) + 'x' + str(
                    shape[2]) + 'x' + str(shape[3]) + ','
        res = res[0:-1]
        if not arg_dict['allow_non_output_from_predictor']:
            res += ' -o ' + arg_dict['pred_output_path']
            res += ' --gen-txt-output '
        else:
            res += ' -o ' + os.path.join(arg_dict['pred_output_path'],
                                         "pred.onnx")
        res += ' -b '
        for input_info in input_infos:
            res += (input_info.pred_input_file + ',')
        res = res[0:-1]
        res += ' --march ' + arg_dict['march'].lower()
        if arg_dict['framework'] == 'mxnet':
            res += ' -m ' + arg_dict['model_json']
            res += ' -p ' + arg_dict['model_param']
        elif arg_dict['framework'] == 'tensorflow':
            res += ' -m ' + arg_dict['model_pb']
            res += ' -f tensorflow'
        elif arg_dict['framework'] == 'pytorch':
            res += ' -m ' + arg_dict['model_pt']
            res += ' -f torch '
            res += ' -n '
            for input_info in input_infos:
                res += input_info.feature_name + ','
            res = res[:-1]
            res += ' -t '
            for input_info in input_infos:
                res += input_info.element_type_name + ','
            res = res[:-1]
        else:
            raise RuntimeError
    except Exception:
        traceback.print_exc()
        logging.critical('can not generate predrun parameters from arg dict!')
        sys.exit(1)
    return res


# https://stackoverflow.com/questions/5255220/fcntl-flock-how-to-implement-a-timeout
# To implement timeout on fcntl
@contextmanager
def context_timeout(seconds=0, error_msg=None):
    if not seconds:
        yield
        return

    def timeout_handler(signum, frame):
        raise RuntimeError(error_msg or "timeout")

    original_handler = signal.signal(signal.SIGALRM, timeout_handler)
    try:
        signal.alarm(int(math.ceil(seconds)))
        yield
    finally:
        signal.alarm(0)
        signal.signal(signal.SIGALRM, original_handler)


program_to_print_pid = 'echo The PID is $PPID.'
regex_to_parse_pid = r'The PID is (\d+)\.'


def connect_to_bpu_and_get_lock(total_time_to_connect,
                                total_time_to_acquire_lock):
    timeout = arg_dict['bpu_timeout']
    lock_timeout = arg_dict['lock_timeout']

    bpu_flock_cmd = "flock -x /tmp/hbdk_model_verifier.lock"
    bpu = None
    bpu_lock_result = None
    logging.info('======> Try to connect BPU')
    bpu_connected_and_lock_acquired = False
    bpu = None
    while True:
        if total_time_to_connect > timeout:
            raise RuntimeError("Timeout exceeds while connecting to bpu")
        if lock_timeout and total_time_to_acquire_lock > lock_timeout:
            raise RuntimeError("Lock timeout exceeds while connecting to bpu")
        try:
            start_connect_time = time.time()
            try:
                bpu = BPUBoard(arg_dict['ip'], arg_dict['port'],
                               arg_dict['username'], arg_dict['password'])
                bpu.connect()
                logging.info('======> BPU connected')
            finally:
                total_time_to_connect += time.time() - start_connect_time

            bpu_lock_start_time = time.time()
            try:
                max_bpu_lock_time = max(3600, timeout + 1800)
                bpu_acquiring_lock_msg = "Acquiring lock for model verifier on bpu"
                bpu_lock_acquired_msg = "Model verifier %s from %s lock on bpu has been acquired" \
                                        % (arg_dict['remote_work_path'], arg_dict['local_work_path'])
                logging.info(bpu_acquiring_lock_msg)
                bpu_lock_result = bpu.exec_command(
                    bpu_flock_cmd + " sh -c \'%s; echo %s; sleep %s\'" %
                    (program_to_print_pid, bpu_lock_acquired_msg,
                     str(max_bpu_lock_time)),
                    bufsize=0,
                    no_wait=True,
                    get_pty=True,
                    name="Verifier Global Lock")

                bpu_lock_handled_event = threading.Event()
                is_bpu_lock_acquired = False

                def acquire_bpu_lock():
                    nonlocal is_bpu_lock_acquired
                    try:
                        while bpu_lock_result.stdout:
                            line = bpu_lock_result.stdout.readline()
                            if bpu_lock_handled_event.is_set():
                                break
                            if not line:
                                break
                            pid_match = re.search(regex_to_parse_pid, line)
                            if pid_match:
                                try:
                                    bpu_lock_result.pid = int(
                                        pid_match.groups()[0])
                                    logging.info(
                                        "REMOTE: The PID of the lock is %s" %
                                        str(bpu_lock_result.pid))
                                except (IOError, ValueError):
                                    traceback.print_exc()
                                    logging.warning(
                                        "Fail to get the pid of the lock program"
                                    )
                            if line.find(bpu_lock_acquired_msg) != -1:
                                is_bpu_lock_acquired = True
                                break
                    finally:
                        bpu_lock_handled_event.set()
                    return is_bpu_lock_acquired

                def helper_no_lock_for_a_while():
                    nonlocal bpu_lock_handled_event
                    bpu_lock_handled_event.set()

                bpu_lock_retry_internal = 60
                time_until_timeout = bpu_lock_retry_internal
                if lock_timeout:
                    time_until_timeout = min(
                        bpu_lock_retry_internal,
                        max(1, lock_timeout - total_time_to_acquire_lock))

                bpu_lock_timer = threading.Timer(time_until_timeout,
                                                 helper_no_lock_for_a_while)
                bpu_lock_timer.daemon = True
                bpu_lock_timer.start()
                bpu_lock_thread = threading.Thread(target=acquire_bpu_lock)
                bpu_lock_thread.start()

                while not bpu_lock_handled_event.is_set():
                    bpu_lock_handled_event.wait()

                bpu_lock_timer.cancel()
                if is_bpu_lock_acquired:
                    bpu_lock_thread.join()
                    bpu_connected_and_lock_acquired = True
                    break
                else:
                    # close lock related stdin/stdout and join thread, to avoid resource leak
                    bpu_lock_result.destroy()
                    bpu_lock_thread.join()
                    bpu_lock_result = None
                    if lock_timeout and total_time_to_acquire_lock > lock_timeout:
                        raise RuntimeError(
                            "Lock timeout exceeds while connecting to bpu")
                    logging.info(
                        "Fail to get bpu lock within %s. Retry connection" %
                        str(bpu_lock_retry_internal))
            finally:
                total_time_to_acquire_lock += time.time() - bpu_lock_start_time
        except (ssh_exception.SSHException, socket.error, EOFError, OSError,
                socket.timeout) as e:
            if e in (ssh_exception.AuthenticationException,
                     ssh_exception.BadAuthenticationType,
                     ssh_exception.PasswordRequiredException,
                     ssh_exception.NoValidConnectionsError,
                     ssh_exception.BadHostKeyException):
                raise
            if total_time_to_connect > timeout:
                raise RuntimeError("Timeout exceeds while connecting to bpu")
            if lock_timeout and total_time_to_acquire_lock > lock_timeout:
                raise RuntimeError(
                    "Lock timeout exceeds while connecting to bpu")
            traceback.print_exc()
            logging.warning(
                "Connection error while connecting to bpu. The error has been printed. "
                "Retrying until timeout exceeds ")
        finally:
            if not bpu_connected_and_lock_acquired:
                try:
                    if bpu_lock_result:
                        bpu_lock_result.destroy()
                    if bpu:
                        bpu.close()
                except Exception:
                    traceback.print_exc()
                    logging.warning(
                        "Unexpected exception while doing bpu cleanup. The exception is printed, but ignored"
                    )
                finally:
                    bpu_lock_result = None
                    bpu = None

    if (not bpu) or (not bpu.is_connected):
        raise RuntimeError("Fail to connect to bpu")
    return bpu, bpu_lock_result, total_time_to_connect, total_time_to_acquire_lock


def dev_upload_exe_to_bpu_board(directory, ip):
    bpu = BPUBoard(ip, 22, 'root', '')
    bpu.connect()
    print("BPU connected")
    bpu.upload(arg_dict['aarch64_so_path'], directory)
    if os.path.exists(arg_dict.get('aarch64_run_model_program_path', '')):
        program = arg_dict['aarch64_run_model_program_path']
    else:
        program = os.path.join(
            os.path.dirname(hbdk.__file__), 'sbin', 'hbdk-run-model-aarch64')
    bpu.upload(program, directory)
    if arg_dict['debug_bpu']:
        bpu.upload(arg_dict['aarch64_hook_so_path'], directory)
    print("Upload complete")


def run_on_bpu_board():
    bisect = None
    if arg_dict['bisect_args']:
        bisect = Bisect(
            start=arg_dict['bisect_start'],
            min_val=arg_dict['bisect_min'],
            max_val=arg_dict['bisect_max'],
            initial_step=arg_dict['bisect_step'],
            fail_on_low=arg_dict['bisect_fail_on_low'])
    bisect_val = None
    any_files_may_have_uploaded = False
    timeout = arg_dict['bpu_timeout']

    lock_timeout = arg_dict['lock_timeout']
    local_lock_file = None
    memcached_lock_file = None
    if arg_dict['bpu_lock_local_file_path']:
        lock_filename = arg_dict['bpu_lock_local_file_path']
        local_acquiring_lock_msg = "Acquiring lock for model verifier on local machine"
        logging.info(local_acquiring_lock_msg)
        local_lock_file = open(lock_filename, "wb")
        with context_timeout(
                lock_timeout,
                "Lock timeout has expired while acquiring lock on local machine"
        ):
            fcntl.lockf(local_lock_file.fileno(), fcntl.LOCK_EX)
        local_lock_acquired_msg = "Model verifier lock on local machine has been acquired"
        logging.info(local_lock_acquired_msg)
        if arg_dict['memcached_server']:
            from hbdk.test import memcached
            memcached_acquiring_lock_msg = "Acquiring lock for model verifier on memcached"
            logging.info(memcached_acquiring_lock_msg)
            with context_timeout(
                    lock_timeout,
                    "Lock timeout has expired while acquiring lock on memcached"
            ):
                server_str = arg_dict['memcached_server']
                assert len(
                    server_str.split(':')
                ) == 2, "The format of cache_server must be HOSTNAME:PORT"
                server = tuple(server_str.split(':'))
                server = (server[0], int(server[1]))
                memcached_lock_file = memcached.FileLock(
                    server=server,
                    filename=lock_filename,
                    connect_timeout=(lock_timeout and int(lock_timeout)
                                     or None),
                    timeout=(lock_timeout and int(lock_timeout) or None),
                    expire=int(arg_dict['bpu_timeout']))
                memcached_lock_file.register_unlock_callback(
                    lambda: logging.info(
                        "Model verifier lock on memcached has been removed"))
                memcached_lock_file.lock()
            memcached_lock_acquired_msg = "Model verifier lock on memcached has been acquired"
            logging.info(memcached_lock_acquired_msg)

    total_time = 0
    total_time_to_connect = 0
    total_time_to_acquire_lock = 0

    bpu, bpu_lock_result = None, None
    may_retry = True
    start_time = time.time()
    time_before_lock = time.time()
    time_after_lock = time.time()
    bpu_stress_result = None
    run_result = None

    uploaded_files = set()

    keep_bpu_stuffs = False

    while True:
        if total_time > timeout:
            raise RuntimeError('bpu execution has timeout(%s)' % str(timeout))
        try:
            if bisect:
                bisect_val = bisect.next_value()
                logging.info(
                    '======> Current Bisect Result: %s : Success on %s\n' %
                    (str(arg_dict['bisect_tag']),
                     str(bisect.get_most_important_success_value())))
                logging.info(
                    '======> Current Bisect Result: %s : Failure on %s\n' %
                    (str(arg_dict['bisect_tag']),
                     str(bisect.get_most_important_failed_value())))
                logging.info('======> Current Testing: %s : %s\n' % (str(
                    arg_dict['bisect_tag']), str(bisect_val)))
            time_before_lock = time.time()
            if (not keep_bpu_stuffs) or (not bpu) or (not bpu_lock_result):
                bpu, bpu_lock_result, total_time_to_connect, total_time_to_acquire_lock = \
                    connect_to_bpu_and_get_lock(total_time_to_connect, total_time_to_acquire_lock)
            time_after_lock = time.time()
            if arg_dict['clean_remote_work_path'] and (not keep_bpu_stuffs):
                bpu.exec_command(
                    'rm -rf %s/hbmv*' % arg_dict['remote_work_root'],
                    timeout=timeout)
            any_files_may_have_uploaded = True
            if not keep_bpu_stuffs:
                bpu.exec_command(
                    'mkdir -p ' + arg_dict['remote_work_path'],
                    timeout=timeout)
                arg_dict['bpu_output_path'] = os.path.join(
                    arg_dict['remote_work_path'], 'bpu_output')
                bpu.exec_command(
                    'mkdir -p ' + arg_dict['bpu_output_path'], timeout=timeout)
                if arg_dict['debug_bpu']:
                    arg_dict['bpu_debug_path'] = os.path.join(
                        arg_dict['remote_work_path'], 'bpu_debug')
                    bpu.exec_command(
                        'mkdir -p ' + arg_dict['bpu_debug_path'],
                        timeout=timeout)
            uploaded_files_is_executable = OrderedDict()

            def upload_file(filename, dest_folder):
                real_filename = os.path.realpath(filename)
                if real_filename in uploaded_files:
                    return
                is_executable = os.access(filename, os.X_OK)
                basename = os.path.basename(filename)
                dest_with_filename = os.path.join(dest_folder, basename)
                relative_dest_with_filename = os.path.relpath(
                    dest_with_filename, arg_dict['remote_work_path'])
                uploaded_files_is_executable[
                    relative_dest_with_filename] = is_executable
                bpu.upload(filename, dest_folder)
                if os.path.exists(filename + ".debug"):
                    bpu.upload(
                        filename + ".debug",
                        os.path.join(dest_folder, os.path.basename(filename)),
                        dest_is_dir=False)
                elif os.path.exists(os.path.realpath(filename) + ".debug"):
                    bpu.upload(
                        os.path.realpath(filename) + ".debug",
                        os.path.join(dest_folder, os.path.basename(filename)),
                        dest_is_dir=False)
                uploaded_files.add(real_filename)

            def upload(folder_or_file):
                dest_dir = arg_dict['remote_work_path']
                if os.path.isfile(folder_or_file):
                    return upload_file(folder_or_file, dest_dir)
                dest_dir = os.path.abspath(
                    os.path.join(dest_dir, os.path.basename(folder_or_file)))
                for root, dirs, files in os.walk(folder_or_file):
                    cur_dest_dir = os.path.abspath(
                        os.path.join(dest_dir,
                                     os.path.relpath(root, folder_or_file)))
                    if root not in uploaded_files:
                        bpu.exec_command(
                            'mkdir -p ' + cur_dest_dir, timeout=timeout)
                    uploaded_files.add(root)
                    for f in files:
                        upload_file(os.path.join(root, f), cur_dest_dir)

            if arg_dict['has_model']:
                bpu.upload(arg_dict['hbm_path'], arg_dict['remote_work_path'])

            upload(arg_dict['aarch64_so_path'])
            upload(arg_dict['aarch64_run_model_program_path'])
            if arg_dict['debug_bpu']:
                upload(arg_dict['aarch64_hook_so_path'])
            if arg_dict['test_program']:
                upload(arg_dict['test_program'])
            if arg_dict['upload_files']:
                for f in arg_dict['upload_files']:
                    upload(f)
            if arg_dict['has_model']:
                for input_info in input_infos:
                    upload(input_info.bpu_input_file)
                    if input_info.vio_config:
                        upload(input_info.vio_config)
            chmod_cmd= 'flock -x /tmp/hbdk_model_verifier.lock2 sh -c ' + \
                       '\'%s; cd %s ; %s \'' % (program_to_print_pid, arg_dict['remote_work_path'],
                       ' ; '.join([('chmod +x %s' % x) for x in uploaded_files_is_executable.keys() if uploaded_files_is_executable[x]]))
            run_result = bpu.exec_command(
                chmod_cmd,
                timeout=timeout,
                log_stdout=arg_dict['verbose'],
                log_stderr=True,
                parse_pid_regex=regex_to_parse_pid,
                name="Chmod")
            if bisect:
                bisect_cmd = 'flock -x /tmp/hbdk_model_verifier.lock2 sh -c ' +\
                              '\'%s; cd %s && %s %s;\'' % \
                      (program_to_print_pid, arg_dict['remote_work_path'], arg_dict['bisect_args'],
                      (bisect_val is None) and arg_dict['bisect_start'] or str(bisect_val))
                run_result = bpu.exec_command(
                    bisect_cmd,
                    timeout=timeout,
                    log_stdout=arg_dict['verbose'],
                    log_stderr=True,
                    parse_pid_regex=regex_to_parse_pid,
                    name="Model Executor")
                if bisect_val is None:  # Finish
                    keep_bpu_stuffs = False
                    break
                if run_result.exit_code == 125:  # Skip
                    bisect.add_result(bisect_val, BisectStatus.Skip)
                    keep_bpu_stuffs = True
                    continue
                elif run_result.exit_code != 0:  # Fatal error
                    logging.critical(
                        "Bisect commands: %s, return expected exit code %s" %
                        (bisect_cmd, str(run_result.exit_code)))
                    sys.exit(1)

            if arg_dict['stress_args']:
                upload(
                    os.path.join(
                        os.path.dirname(
                            arg_dict['aarch64_run_model_program_path']),
                        'stress-ng-aarch64'))
                bpu_stress_result = bpu.exec_command(
                    " sh -c \'%s; cd %s && chmod u+x ./stress-ng-aarch64 && ./stress-ng-aarch64 --timeout %s %s\'"
                    % (program_to_print_pid, arg_dict['remote_work_path'],
                       str(timeout), arg_dict['stress_args']),
                    get_pty=True,
                    name="Stress program",
                    no_wait=True)

                def read_stress_output():
                    try:
                        while bpu_stress_result.stdout:
                            line = bpu_stress_result.stdout.readline()
                            if line and line.strip():
                                logging.info(line.strip())
                            pid_match = re.search(regex_to_parse_pid, line)
                            if pid_match:
                                try:
                                    bpu_stress_result.pid = int(
                                        pid_match.groups()[0])
                                    logging.info(
                                        "REMOTE: The PID of the stress is %s" %
                                        str(bpu_stress_result.pid))
                                except (IOError, ValueError):
                                    traceback.print_exc()
                                    logging.warning(
                                        "Fail to get the pid of the stress program"
                                    )
                    except (IOError, AttributeError):
                        # AttributeError to avoid bpu_stress_result.stdout raise exception when bpu_stress_result assigned to None
                        pass

                stress_stdout_thread = threading.Thread(
                    target=read_stress_output)
                stress_stdout_thread.start()
                time.sleep(1)

            # Another lock to ensure locking when hbdk-model-verifier is interrupted
            # The global flock would receive SIGHUP before the following command
            cmd = 'flock -x /tmp/hbdk_model_verifier.lock2 sh -c \''
            cmd += '%s; ' % program_to_print_pid
            cmd += 'echo BPU execution begins; cd ' + arg_dict[
                'remote_work_path']
            cmd += ' ; echo the local work path is %s' % arg_dict[
                'local_work_path']
            cmd += ' ; ulimit -c 0; sync'
            cmd += ' ; echo BPU model execution begins; if [ -f "/etc/profile" ]; then\n source /etc/profile \n fi;'
            cmd += gen_run_cmd_param(False)
            cmd += ' && echo BPU model execution ends'
            if (not arg_dict['no_bpu_clean']) and (not keep_bpu_stuffs) and (
                    not bisect):
                # Save as much disk space as possible before making tar
                cmd += ' && rm -rf %s' % " ".join(
                    uploaded_files_is_executable.keys())

            cmd += ' && echo Begin to compress model output && tar -czvf bpu_output.tar.gz bpu_output'
            if arg_dict['debug_bpu']:
                cmd += ' && tar -cvf bpu_debug.tar bpu_debug'
            cmd += '\''
            if (not arg_dict['no_bpu_clean']) and (not keep_bpu_stuffs) and (
                    not bisect):
                cmd += ' && rm -rf bpu_output '
            cmd += ";exit_code=$?; echo BPU execution ends; exit $exit_code"
            run_result = bpu.exec_command(
                cmd,
                timeout=timeout,
                log_stdout=arg_dict['verbose'],
                log_stderr=True,
                parse_pid_regex=regex_to_parse_pid,
                name="Model Executor")

            def download_result():
                bpu.download(
                    os.path.join(arg_dict['remote_work_path'],
                                 'bpu_output.tar.gz'),
                    arg_dict['local_work_path'])
                if arg_dict['debug_bpu']:
                    bpu.download(
                        os.path.join(arg_dict['remote_work_path'],
                                     'bpu_debug.tar'),
                        arg_dict['local_work_path'])

            if run_result.exit_code != 0:
                msg = "bpu execution returns non-zero exit code " + str(
                    run_result.exit_code)
                logging.critical(msg)
                if bisect:
                    bisect.add_result(bisect_val, BisectStatus.Fail)
                    keep_bpu_stuffs = True
                    continue
                else:
                    raise RuntimeError(msg)
            elif bisect:
                bisect.add_result(bisect_val, BisectStatus.Success)
                keep_bpu_stuffs = True
                continue
            elif bpu_stress_result and bpu_stress_result.exit_code > 0:
                msg = "bpu stress returns non-zero exit code " + str(
                    bpu_stress_result.exit_code)
                logging.critical(msg)
                raise RuntimeError(msg)
            else:
                max_retry_times = 5
                for i in range(max_retry_times):
                    try:
                        download_result()
                        break
                    except IOError:
                        if i >= max_retry_times - 1:
                            may_retry = False
                            raise
                        else:
                            time.sleep(10)
            break
        except (ssh_exception.SSHException, socket.error, EOFError, OSError,
                socket.timeout) as e:
            try:
                if e in (ssh_exception.AuthenticationException,
                         ssh_exception.BadAuthenticationType,
                         ssh_exception.PasswordRequiredException,
                         ssh_exception.NoValidConnectionsError,
                         ssh_exception.BadHostKeyException):
                    raise
                if not may_retry:
                    raise
                total_time += time.time() - time_before_lock
                if total_time > timeout:
                    raise RuntimeError(
                        'bpu execution has timeout(%s)' % str(timeout))
            except Exception:
                if memcached_lock_file:
                    memcached_lock_file.unlock()
                if local_lock_file:
                    local_lock_file.close()
                raise
            traceback.print_exc()
            logging.warning(
                "Connection error while working on bpu. Retrying until the timeout exceeds"
            )
            time.sleep(5)
            keep_bpu_stuffs = False
        finally:
            try:
                if bpu_lock_result and (not keep_bpu_stuffs):
                    bpu_lock_result.destroy()
                if bpu_stress_result:
                    bpu_stress_result.destroy()
                    bpu_stress_result = None
                if bpu and (not keep_bpu_stuffs):
                    if any_files_may_have_uploaded and (
                            not arg_dict['no_bpu_clean']):
                        cmd = ' rm -rf ' + arg_dict['remote_work_path'] + "; "
                        bpu.exec_command(cmd, timeout=timeout)
                    bpu.close()
            except Exception:
                traceback.print_exc()
                logging.warning(
                    "Unexpected exception while doing bpu cleanup. The exception is printed, but ignored"
                )
            finally:
                if not keep_bpu_stuffs:
                    bpu_lock_result = None
                    bpu = None
                    uploaded_files.clear()
                any_files_may_have_uploaded = False

    if memcached_lock_file:
        memcached_lock_file.unlock()
    if local_lock_file:
        local_lock_file.close()

    if bisect:
        logging.info('======> Bisect Result: %s : Success on %s\n' %
                     (str(arg_dict['bisect_tag']),
                      str(bisect.get_most_important_success_value())))
        logging.info('======> Bisect Result: %s : Failure on %s\n' %
                     (str(arg_dict['bisect_tag']),
                      str(bisect.get_most_important_failed_value())))
        return

    if arg_dict['has_model']:
        logging.info(
            'Verifier Total Time on dev board with connection time'
            ' (including BPU, CPU, IO, network and time to wait for lock): %f ms'
            % (time.time() - start_time))
        logging.info('Verifier Total Time on dev board without connection time'
                     ' (including BPU, CPU, IO and network time): %f ms' %
                     (time.time() - time_after_lock))

        parse_output_keywords = OrderedDict([
            ('total_avg', '[TIME] Average time for each model executions'),
            ('bpu_avg',
             '[TIME] Average plain funccall times for each model executions'),
            ('cpu_avg', '[TIME] Average CPU Time for each model executions'),
        ])
        if arg_dict['is_developer']:
            parse_output_keywords[
                'total_stddev'] = '[TIME] StdDev of time for model executions'
            parse_output_keywords[
                'bpu_stddev'] = '[TIME] StdDev of plain funccall times for model executions'
            parse_output_keywords[
                'cpu_stddev'] = '[TIME] StdDev of CPU Time for model executions'
        try:
            for line in run_result.stdout:
                for key, keyword in parse_output_keywords.items():
                    idx0 = line.find(keyword)
                    if idx0 != -1:
                        idx0 = line.find(': ')
                        idx0 += len(': ')
                        idx1 = line.find('ms', idx0)
                        time_ms = line[idx0:idx1]
                        arg_dict[key] = float(time_ms)
            if not all([
                    arg_dict.get(key) is not None
                    for key in parse_output_keywords.keys()
            ]):
                logging.warning(
                    'extract model execution time from bpu log failed!')
            else:
                logging.info(
                    '\n\n======> Model execution time (including BPU and CPU): %f ms\n'
                    '======> BPU execution time (BPU function call consumed time): %f ms\n'
                    '======> CPU execution time (including context switch and cpu operator): %f ms\n'
                    % (arg_dict['total_avg'], arg_dict['bpu_avg'],
                       arg_dict['cpu_avg']))
                if arg_dict['is_developer']:
                    logging.info(
                        '\n\n======> Model time stddev(including BPU and CPU): %f ms\n'
                        '======> BPU time stddev (BPU function call consumed time): %f ms\n'
                        '======> CPU time stddev (including context switch and cpu operator): %f ms\n'
                        % (arg_dict['total_stddev'], arg_dict['bpu_stddev'],
                           arg_dict['cpu_stddev']))

        except (ValueError, IndexError):
            logging.warning(
                'extract model execution time from bpu log failed!')
        if run_result:
            run_result.destroy()
        os.chdir(arg_dict['local_work_path'])
        if arg_dict['debug_bpu']:
            execute_shell_cmd('tar -xvf bpu_debug.tar')
            #execute_shell_cmd('rm bpu_debug.tar')
        execute_shell_cmd('tar -xvf bpu_output.tar.gz')
        execute_shell_cmd('rm bpu_output.tar.gz')
        if arg_dict['extra_args'].find('--no-dump-output') == -1:
            output_generated = False
            for file in os.listdir('bpu_output'):
                if file.find('hbdk_output') != -1:
                    output_generated = True
            if not output_generated:
                logging.critical(
                    'output is not generated by remote BPU board. Please check log for more details.'
                )
                sys.exit(1)
        arg_dict['bpu_output_path'] = os.path.join(arg_dict['local_work_path'],
                                                   'bpu_output')


def run_by_simulator(force_dump_snapshot=False, enable_debugging=True):
    logging.info('======> Run Model by Simulator')
    orig_sim_output_path = arg_dict['sim_output_path']
    if not enable_debugging:
        arg_dict['sim_output_path_ref'] = os.path.abspath(
            arg_dict['sim_output_path']) + '_ref'
        os.makedirs(arg_dict['sim_output_path_ref'], exist_ok=True)
        arg_dict['sim_output_path'] = arg_dict['sim_output_path_ref']
    cmd = gen_run_cmd_param(
        for_sim=True,
        force_dump_snapshot=force_dump_snapshot,
        enable_debugging=enable_debugging)
    orig_path = os.getcwd()
    os.chdir(arg_dict['sim_output_path'])
    out, err, returncode = execute_shell_cmd(cmd)
    if out and arg_dict['verbose']:
        logging.warning('receive following output from simulator:')
        logging.info(out)
    if err:
        logging.warning('receive following warning from simulator:')
        logging.warning(err)
    if returncode != 0:
        logging.critical('Fail to execute {}'.format(cmd))
        sys.exit(1)
    output_generated = False
    for file in os.listdir(arg_dict['sim_output_path']):
        if file.find('hbdk_output') != -1:
            output_generated = True
    if not output_generated:
        logging.critical(
            'output is not generated by simulator. Please check log for more details.'
        )
        sys.exit(1)
    os.chdir(orig_path)
    if not enable_debugging:
        arg_dict['sim_output_path'] = orig_sim_output_path
    logging.info('======> Run Model by Simulator Done.')


def find_option_str(str, key_lst):
    for key in key_lst:
        idx0 = str.find(key)
        if idx0 != -1:
            idx0 += len(key)
            idx1 = str.find(' -', idx0)
            if idx1 != -1:
                return str[idx0:idx1].strip()
            else:
                return str[idx0:].strip()
    return None


def check_hbm_info_against_arg_dict():
    mixed_version_string = arg_dict['model_info']['hbdk-cc version']
    if mixed_version_string.find('runtime version') != -1:
        mo = re.search('runtime version: ([^;]+);', mixed_version_string)
    else:
        mo = re.match('version: ([^;]+);', mixed_version_string)
    if mo:
        arg_dict['hbm_runtime_version'] = mo.group(1)
    else:
        arg_dict['hbm_runtime_version'] = "unknown"
        logging.warning('Failed to get hbdk runtime version from HBM')

    if arg_dict['hbdk_runtime_version'] != arg_dict['hbm_runtime_version']:
        logging.warning(
            'This hbm was compiled by using the runtime version ' +
            arg_dict['hbm_runtime_version'] +
            ', while the hbdk runtime in your environment is ' +
            arg_dict['hbdk_runtime_version'] +
            '. Please recompile your model or install a compatible version of hbdk-model-verifier'
            + ' if encounter any issue.')


def run_model_by_framework():
    if arg_dict['use_exist_pred_output']:
        logging.info(
            "Use exist predictor output. Will not run predictor this time")
        return
    cmd = 'hbdk-pred '
    param = gen_run_framework_pred_cmd_param()
    cmd += param
    logging.info('======> Run Model by hbdk-pred')
    out, err, returncode = execute_shell_cmd(cmd)
    if out and arg_dict['verbose']:
        logging.info('receive following output from hbdk-pred')
        if isinstance(out, list):
            for line in out:
                line = line.strip()
                if len(line):
                    logging.info(line)
        else:
            logging.info(out)
    if err:
        logging.warning('receive following warning from hbdk-pred')
        if isinstance(err, list):
            for line in err:
                line = line.strip()
                if len(line):
                    logging.info(line)
        else:
            logging.info(err)
    if returncode != 0:
        logging.critical('Fail to execute {}'.format(cmd))
        sys.exit(1)
    if not os.path.exists(arg_dict['pred_output_path']):
        logging.critical(
            'output is not generated by hbdk-pred. Please check log for more details.'
        )
        sys.exit(1)


def find_matched_bpu_output_by_framework_output(framework_output_filename,
                                                bpu_output_dir):
    feature_name_match = re.match(
        r"hbdk_output_(.+?)(?:\d+|)(?:_inhardwarelayout|)\.txt",
        framework_output_filename)
    if not feature_name_match:
        raise RuntimeError("Unexpected output filename from framework " +
                           framework_output_filename)
    feature_name = feature_name_match.groups()[0]
    matched_files = []
    for file in os.listdir(bpu_output_dir):
        match = re.match(
            r"hbdk_output\d+_feature_%s(?:\d+|)(?:_inhardwarelayout|)(?:_orig_bpu|)(?:_dpp_sort_ref|)(?:\:.*|)?"
            r"_elem_.*\.txt" % feature_name, file)
        if match:
            matched_files.append(file)
    return matched_files


def compare_channel_argmax_output(framework_output_nparray,
                                  bpu_output_file_lines):
    bpu_data_line_start = 0
    valid_dim_key = '#valid_dim='
    dynamic_n_key = '#dynamic_n='
    shape = []
    line_num = len(bpu_output_file_lines)
    while bpu_data_line_start < line_num and bpu_output_file_lines[
            bpu_data_line_start][0] == '#':
        if bpu_output_file_lines[bpu_data_line_start].startswith(
                valid_dim_key):
            shape = list(
                shape_arg_to_tuple(bpu_output_file_lines[bpu_data_line_start]
                                   [len(valid_dim_key):]))
        elif bpu_output_file_lines[bpu_data_line_start].startswith(
                dynamic_n_key):
            shape[0] = int(bpu_output_file_lines[bpu_data_line_start]
                           [len(dynamic_n_key):])
        bpu_data_line_start += 1
    elem_num = shape[0] * shape[1] * shape[2] * shape[3]
    if elem_num == 0:
        return True, ""
    bpu_data = np.loadtxt(bpu_output_file_lines[bpu_data_line_start:])
    bpu_data = bpu_data.flatten()[0:elem_num]
    framework_output_nparray = framework_output_nparray.flatten()[0:elem_num]
    if len(framework_output_nparray) * 2 == len(
            bpu_data):  ## keep score = false
        bpu_label = bpu_data[1::2]
        bpu_score = bpu_data[0::2]
        label_equal, reason = compare_ndarray(bpu_label,
                                              framework_output_nparray)
        if label_equal:
            return label_equal, reason
        return compare_ndarray(bpu_score, framework_output_nparray)
    return compare_ndarray(bpu_data, framework_output_nparray)


def compare_filter_output(framework_output_nparray, bpu_output_file_lines):
    valid_dim_key = '#valid_dim = '
    bpu_data_line_start = 0
    shape = []
    line_num = len(bpu_output_file_lines)
    while bpu_data_line_start < line_num and bpu_output_file_lines[
            bpu_data_line_start][0] == '#':
        if bpu_output_file_lines[bpu_data_line_start].startswith(
                valid_dim_key):
            shape = list(
                shape_arg_to_tuple(bpu_output_file_lines[bpu_data_line_start]
                                   [len(valid_dim_key):]))
        bpu_data_line_start += 1
    elem_num = shape[0] * shape[1]
    if elem_num == 0:
        return True, ""

    def _compose_int16(lhs, rhs):
        # inverse operation of decompose_int16 in pred_torch.py
        return lhs.astype(np.uint8).astype(
            np.int16) + (rhs.astype(np.int16) << 8)

    bpu_data = np.loadtxt(bpu_output_file_lines[bpu_data_line_start:])
    is_int16_output = (
        bpu_data.shape[-1] == framework_output_nparray.shape[-1])
    framework_coord_start = 4
    framework_coord_end = 8
    framework_data_start = 8
    framework_score_start = 2
    if is_int16_output:
        framework_coord_start = 2
        framework_coord_end = 4
        framework_data_start = 4
        framework_score_start = 1
    bpu_coord = bpu_data[:, 2:4]
    framework_coord_raw = framework_output_nparray[:, framework_coord_start:
                                                   framework_coord_end]
    framework_coord = []
    if not is_int16_output:
        for coord in framework_coord_raw:
            framework_coord.append([
                _compose_int16(coord[0], coord[1]),
                _compose_int16(coord[2], coord[3])
            ])
    else:
        framework_coord = framework_coord_raw
    framework_coord = np.array(framework_coord)
    bpu_data_sorted = np.hstack((bpu_data[:, 0:2], bpu_data[:, 4:]))
    bpu_data_sorted = bpu_data_sorted[np.lexsort((bpu_coord[:, 1],
                                                  bpu_coord[:, 0]))]
    framework_sorted = np.hstack(
        (np.expand_dims(framework_output_nparray[:, 0], axis=1),
         np.expand_dims(
             framework_output_nparray[:, framework_score_start], axis=1),
         framework_output_nparray[:, framework_data_start:]))
    framework_sorted = framework_sorted[np.lexsort((framework_coord[:, 1],
                                                    framework_coord[:, 0]))]
    return compare_ndarray(bpu_data_sorted, framework_sorted)


def compare_ndarray(bpu_data, framework_output_nparray):
    if bpu_data.shape != framework_output_nparray.shape:
        return False, "Unmatched output shape. bpu/sim: %s, framework: %s" \
               % (str(bpu_data.shape), str(framework_output_nparray.shape))
    bpu_data = bpu_data.flatten()
    framework_output_nparray = framework_output_nparray.flatten()
    diff = abs(bpu_data - framework_output_nparray)
    res = (diff <= arg_dict['diff_threshold'])
    if not isinstance(res, bool):
        res = res.all()
    if not res:
        return False, "The max element difference is above the threshold: %.20e" % (
            float(max(diff)))
    return True, ""


def compare_dpp_output(framework_output_nparray, bpu_output_file_lines):
    box_num_header = '#box_num = '
    if bpu_output_file_lines[0].find(box_num_header) == -1:
        return False, "Missing #box_num header in bpu/sim output"
    bpu_box_num = int(bpu_output_file_lines[0][len(box_num_header):])
    framework_box_num = int(framework_output_nparray[0][0] / 16)
    if framework_box_num < 0:
        framework_box_num = int((framework_output_nparray[0][0] + 65536) / 16)
    if bpu_box_num < framework_box_num:
        return False, "Unmatched number of boxes. bpu/sim: %d, framework: %d" \
               % (bpu_box_num, framework_box_num)
    if bpu_box_num == 0:
        return True, ""
    bpu_data_line_start = 0
    while bpu_output_file_lines[bpu_data_line_start][0] == '#':
        bpu_data_line_start += 1
    bpu_data = np.loadtxt(bpu_output_file_lines[bpu_data_line_start:])
    if bpu_data.ndim == 1:
        bpu_data = bpu_data.reshape((1, bpu_data.shape[0]))
    bpu_data_merge_score_label = np.zeros(
        (bpu_data.shape[0], bpu_data.shape[1] - 1), dtype=bpu_data.dtype)
    for i in range(bpu_data.shape[0]):
        bpu_data_merge_score_label[i][0:4] = bpu_data[i][0:4]
        bpu_data_merge_score_label[i][
            4] = bpu_data[i][5] * 256 + bpu_data[i][4]
    bpu_data_merge_score_label = bpu_data_merge_score_label[:framework_box_num]
    framework_data = framework_output_nparray[1:framework_box_num + 1]
    good, reason = compare_ndarray(bpu_data_merge_score_label, framework_data)
    if not good:
        if bpu_box_num != framework_box_num:
            return False, "Unmatched number of boxes. bpu/sim: %d, framework: %d" \
                   % (bpu_box_num, framework_box_num)
    return good, reason


def compare_rpp_output(framework_output_nparray, bpu_output_file_lines):
    elem_type_header = '#elem_type: '
    if bpu_output_file_lines[0].find(elem_type_header) == -1:
        return False, "Missing #elem_type header in bpu/sim output"
    elem_type = (bpu_output_file_lines[0][len(elem_type_header):]).strip()
    if elem_type == 'int16':
        data_size = 16
    elif elem_type == 'float':
        data_size = 24
    else:
        return False, "Unexpected bpu/sim output element type " + str(
            elem_type)
    box_num_header = '#box_num = '
    if bpu_output_file_lines[1].find(box_num_header) == -1:
        return False, "Missing #box_num header in bpu/sim output"
    bpu_box_num = int(bpu_output_file_lines[1][len(box_num_header):])
    framework_box_num = int(framework_output_nparray[0][0] / data_size)
    if bpu_box_num != framework_box_num:
        return False, "Unmatched number of boxes. bpu/sim: %d, framework: %d" \
               % (bpu_box_num, framework_box_num)
    if bpu_box_num == 0:
        return True, ""
    bpu_data_line_start = 0
    while bpu_output_file_lines[bpu_data_line_start][0] == '#':
        bpu_data_line_start += 1
    bpu_data = np.loadtxt(bpu_output_file_lines[bpu_data_line_start:])
    if bpu_data.ndim == 1:
        bpu_data = bpu_data.reshape((1, bpu_data.shape[0]))
    if elem_type == 'int16':
        bpu_data_merge_score_label = np.zeros(
            (bpu_data.shape[0], bpu_data.shape[1] - 1), dtype=bpu_data.dtype)
        for i in range(bpu_data.shape[0]):
            bpu_data_merge_score_label[i][0:4] = bpu_data[i][0:4]
            bpu_data_merge_score_label[i][
                4] = bpu_data[i][5] * 256 + bpu_data[i][4]
    else:
        bpu_data_merge_score_label = bpu_data
    framework_data = framework_output_nparray[1:bpu_box_num + 1]
    return compare_ndarray(bpu_data_merge_score_label, framework_data)


def compare_conv_or_unknown_output(framework_output_nparray,
                                   bpu_output_file_lines):
    bpu_data_line_start = 0
    valid_dim_key = '#valid_dim='
    dynamic_n_key = '#dynamic_n='
    shape = []
    line_num = len(bpu_output_file_lines)
    while bpu_data_line_start < line_num and bpu_output_file_lines[
            bpu_data_line_start][0] == '#':
        if bpu_output_file_lines[bpu_data_line_start].startswith(
                valid_dim_key):
            shape = list(
                shape_arg_to_tuple(bpu_output_file_lines[bpu_data_line_start]
                                   [len(valid_dim_key):]))
        elif bpu_output_file_lines[bpu_data_line_start].startswith(
                dynamic_n_key):
            shape[0] = int(bpu_output_file_lines[bpu_data_line_start]
                           [len(dynamic_n_key):])
        bpu_data_line_start += 1
    elem_num = shape[0] * shape[1] * shape[2] * shape[3]
    if elem_num == 0:
        return True, ""
    bpu_data = np.loadtxt(bpu_output_file_lines[bpu_data_line_start:])
    bpu_data = bpu_data.flatten()[0:elem_num]
    framework_output_nparray = framework_output_nparray.flatten()[0:elem_num]
    return compare_ndarray(bpu_data, framework_output_nparray)


def compare_dpp_stable_sort_output(framework_output_nparray,
                                   bpu_output_file_lines):
    box_num_header = '#box_num = '
    if bpu_output_file_lines[0].find(box_num_header) == -1:
        return False, "Missing #box_num header in bpu/sim output"
    bpu_box_num = int(bpu_output_file_lines[0][len(box_num_header):])
    framework_box_num = int(framework_output_nparray[0][0] / 16)
    if framework_box_num < 0:
        framework_box_num = int((framework_output_nparray[0][0] + 65536) / 16)
    if bpu_box_num > framework_box_num * 1.25 or bpu_box_num < framework_box_num * 0.75:
        return False, "The number of box of bpu/sim is not within 0.25 of number of box of framework." \
                      " bpu/sim: %d, framework: %d" % (bpu_box_num, framework_box_num)
    if framework_box_num == 0:
        return True, ""
    bpu_data_line_start = 0
    while bpu_output_file_lines[bpu_data_line_start][0] == '#':
        bpu_data_line_start += 1
    bpu_data = np.loadtxt(bpu_output_file_lines[bpu_data_line_start:])
    if bpu_data.ndim == 1:
        bpu_data = bpu_data.reshape((1, bpu_data.shape[0]))
    bpu_data_merge_score_label = np.zeros(
        (bpu_data.shape[0], bpu_data.shape[1] - 1), dtype=bpu_data.dtype)
    for i in range(bpu_data.shape[0]):
        bpu_data_merge_score_label[i][0:4] = bpu_data[i][0:4]
        bpu_data_merge_score_label[i][
            4] = bpu_data[i][5] * 256 + bpu_data[i][4]
    framework_data = framework_output_nparray[1:framework_box_num + 1]
    min_box_num = min(framework_box_num, bpu_box_num)
    sorted_frame_work_data = np.sort(framework_data, axis=0)[0:min_box_num]
    sorted_bpu_data_merge_score_label = np.sort(
        bpu_data_merge_score_label, axis=0)[0:min_box_num]

    correct_num = 0
    for bpu_box in sorted_bpu_data_merge_score_label:
        if len((np.where(
            (sorted_frame_work_data == bpu_box).all(axis=1)))[0]) != 0:
            correct_num += 1

    bpu_box_precision = correct_num / bpu_box_num

    correct_num = 0
    for pred_box in sorted_frame_work_data:
        if len((np.where((sorted_bpu_data_merge_score_label == pred_box).all(
                axis=1)))[0]) != 0:
            correct_num += 1

    bpu_box_recall = correct_num / framework_box_num
    res = False
    reason = "The bpu/sim output similarity is not within 0.95 of framework output"
    if bpu_box_precision > 0.95 and bpu_box_precision > 0.95:
        if bpu_box_precision != 1 or bpu_box_recall != 1:
            logging.warning("dpp stable sort output has minor difference. " +
                            str(bpu_box_precision) + "recall = " +
                            str(bpu_box_recall) + ", precision = " +
                            str(bpu_box_recall))
        res = True
        reason = ""
    return res, reason


def generate_predictor_txt_by_bpu_output_filenames(bpu_output_dir,
                                                   framework_output_dir,
                                                   onnx_filename=None):
    processed_tensor_names = []
    if onnx_filename is None:
        onnx_filename = os.path.join(framework_output_dir, "pred.onnx")
    onnx_model = OnnxModel.from_filename(onnx_filename)
    for filename in os.listdir(bpu_output_dir):
        if not filename.startswith('hbdk_output'):
            continue
        match = re.match(r"hbdk_output\d+_feature_(.*)_elem_.*\.txt", filename)
        if (not match) or len(match.groups()) == 0:
            raise RuntimeError("Unexpected bpu output filename " +
                               str(filename))
        tensor_name = match.groups()[0]
        if tensor_name in processed_tensor_names:
            continue
        processed_tensor_names.append(tensor_name)
        if not onnx_model.has_tensor_by_name(tensor_name):
            raise RuntimeError(
                "bpu output %s is not in the predictor outputs or intermediates"
                % tensor_name)
        data = onnx_model.get_tensor_by_name(tensor_name)
        output_filename = os.path.join(framework_output_dir,
                                       'hbdk_output_' + tensor_name + '.txt')
        tmp_dim = int(1)
        for dim in data.shape:
            tmp_dim *= dim
        tmp_dim /= data.shape[-1]
        tmp_dim = int(tmp_dim)
        output_reshape = data.reshape((tmp_dim, data.shape[-1]))
        np.savetxt(output_filename, output_reshape, fmt='%.20e')


def compare_bpu_output_with_framework_output(bpu_output,
                                             framework_output,
                                             onnx_output_file=None):
    if onnx_output_file is not None:
        generate_predictor_txt_by_bpu_output_filenames(
            bpu_output, framework_output, onnx_output_file)
    check_pass = True
    if not list(os.listdir(bpu_output)):
        raise RuntimeError("Bpu output is missing in " + str(bpu_output))
    if not list(os.listdir(framework_output)):
        raise RuntimeError("framework output is missing in " +
                           str(framework_output))
    if arg_dict['allow_non_output_from_predictor']:
        generate_predictor_txt_by_bpu_output_filenames(bpu_output,
                                                       framework_output)
    if not [x for x in os.listdir(framework_output) if x.endswith('txt')]:
        raise RuntimeError("framework txt output is missing in " +
                           str(framework_output))
    any_predictor_output_missing = False
    try:
        compare_pattern = {
            'DETECTION_POST_PROCESS': compare_dpp_output,
            'AUX_DPP_STABLE_SORT': compare_dpp_output,
            'DETECTION_POST_PROCESS_STABLE_SORT':
            compare_dpp_stable_sort_output,
            'RCNN_POST_PROCESS': compare_rpp_output,
            'CHANNEL_ARGMAX': compare_channel_argmax_output,
            'FILTER': compare_filter_output,
        }

        for file in os.listdir(framework_output):
            if not file.endswith('.txt'):
                continue
            match = False
            reason = ""
            framework_data = np.loadtxt(os.path.join(framework_output, file))
            bpu_match_files = find_matched_bpu_output_by_framework_output(
                file, bpu_output)
            if not bpu_match_files:
                logging.warning(
                    ' [FAILED] output file [' + file +
                    '] does not have matched result in bpu outputs. ')
                any_predictor_output_missing = True

                check_pass = False
                continue
            else:
                for bpu_file in bpu_match_files:
                    with open(os.path.join(bpu_output, bpu_file)) as f:
                        lines = f.readlines()
                        operator_name = (lines[0][len('#operator: '):]).strip()
                        if operator_name in compare_pattern:
                            this_match, reason = compare_pattern[
                                operator_name](framework_data, lines[1:])
                        else:
                            this_match, reason = compare_conv_or_unknown_output(
                                framework_data, lines[1:])
                        if this_match:
                            match = True
                            break
            if not match:
                check_pass = False
                logging.warning(
                    ' [FAILED]  output file [' + file +
                    '] is different. Reason: %s', reason)
            else:
                logging.info(' [SUCCESS] output file [' + file + '] is same.')
    except Exception:
        traceback.print_exc()
        logging.critical('compare process is broken!')
        sys.exit(1)
    if any_predictor_output_missing:
        logging.warning(
            'The bpu output tensors may not be this same as the predictor output tensors. '
            'Use --allow-non-output-from-predictor to allow check bpu result against predictor '
            'non-output tensors')
    return check_pass


def compare_bpu_output_with_sim_output(bpu_output, sim_output):
    check_pass = True
    try:
        for file in os.listdir(bpu_output):
            if not os.path.exists(os.path.join(sim_output, file)):
                check_pass = False
                logging.warning(' [FAILED]    output file [' + file +
                                '] is not generated by simulator.')
                continue
            bpu_output_crc32 = get_file_crc32(os.path.join(bpu_output, file))
            sim_output_crc32 = get_file_crc32(os.path.join(sim_output, file))
            if bpu_output_crc32 != sim_output_crc32:
                check_pass = False
                logging.warning(' [FAILED] output file [' + file +
                                '] is different.')
            else:
                logging.info(' [SUCCESS] output file [' + file + '] is same.')
    except Exception:
        traceback.print_exc()
        logging.critical('compare process is broken!')
        sys.exit(1)
    return check_pass


def main():
    register_exit_gracefully_handler()
    # enviroment check and model info parse
    if hbdk_model_verifier.__version__ != hbdk.__version__:
        logging.warning(
            'The version of hbdk-model-verifier "{}" does not match the version of hbdk "{}".'
            ' This could cause unexpected behaviors.'.format(
                hbdk_model_verifier.__version__, hbdk.__version__))
    global arg_dict
    arg_dict = parse_args(True)

    check_hbdk_tool_existence()

    if arg_dict['has_model']:
        check_hbm_info_against_arg_dict()
        # generate random input if not given
        if not arg_dict['input_is_given']:
            generate_random_input_files()
        # preprocess input
        preprocess_bpu_input_data()

    # run model by bpu/simulator
    if arg_dict['run_bpu']:
        run_on_bpu_board()

    if arg_dict['run_sim']:
        if arg_dict['skip_bpu'] and arg_dict[
                'bpu_then_simulator_fc_inst_index']:
            run_by_simulator(force_dump_snapshot=True)
        run_by_simulator()

    if arg_dict['extra_args'].find('--no-dump-output') != -1:
        logging.info('Output dump is disabled. Skip comparing output')
        sys.exit(0)

    exit_val = 0

    if arg_dict['has_model'] or arg_dict['reference']:
        # run model by framework
        # first results comparision
        if arg_dict['has_predictor']:
            preprocess_framework_input_data()
            run_model_by_framework()
        if arg_dict['has_predictor'] or arg_dict['reference']:
            if arg_dict['run_bpu'] and (
                    not arg_dict['bpu_then_simulator_fc_inst_index']):
                logging.info(
                    '======> Compare Results on BPU Board vs. Framework')
                result = compare_bpu_output_with_framework_output(
                    arg_dict['bpu_output_path'], arg_dict['pred_output_path'],
                    arg_dict['reference'] or None)
                if not result:
                    exit_val = -1
            if arg_dict['run_sim']:
                logging.info(
                    '======> Compare Results of Simulator vs. Framework')
                result = compare_bpu_output_with_framework_output(
                    arg_dict['sim_output_path'], arg_dict['pred_output_path'],
                    arg_dict['reference'] or None)
                if not result:
                    exit_val = -1
        if arg_dict['run_bpu'] and arg_dict['run_sim']:
            logging.info('======> Compare Results of Simulator vs. BPU Board')
            if arg_dict['bpu_then_simulator_fc_inst_index']:
                run_by_simulator(enable_debugging=False)
                result = compare_bpu_output_with_sim_output(
                    arg_dict['sim_output_path'],
                    arg_dict['sim_output_path_ref'])
            else:
                result = compare_bpu_output_with_sim_output(
                    arg_dict['bpu_output_path'], arg_dict['sim_output_path'])
            if not result:
                exit_val = -1
    sys.exit(exit_val)


if __name__ == "__main__":
    main()
